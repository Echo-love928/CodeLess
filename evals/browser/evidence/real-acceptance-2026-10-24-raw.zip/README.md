# D21 real acceptance raw records

Two full batches; keep their results separate. The first has a confirmed Windows nested-path environment defect. The second uses a short, dedicated detached checkout. Both retain all 14 samples and all 47 canonical report inputs, unchanged. Private preflight files are excluded only because they contain machine paths; their digests and omission reasons are in the accompanying acceptance summary.

Recompute independently with Node 24:

```powershell
node scripts/eval/verify-batch.mjs evals/generation/runs/2026-10-24T13-47-29Z-real-103b5585
node scripts/eval/report.mjs evals/generation/runs/2026-10-24T13-47-29Z-real-103b5585 --check
```

Use the other full batch ID to verify the first. A verifier exit 0 certifies record integrity, not quality acceptance. No credentials or model calls are needed for recomputation.
