export interface Work {
  id: number;
  title: string;
  location: string;
  color: string;
}

export const works: Work[] = [
  {
    id: 1,
    title: "晨雾山脊",
    location: "云南 · 梅里雪山",
    color: "#8fa9c9",
  },
  {
    id: 2,
    title: "旧城光影",
    location: "福建 · 泉州老街",
    color: "#d8a76b",
  },
  {
    id: 3,
    title: "海岸无声",
    location: "广东 · 汕头南澳岛",
    color: "#6fb3a8",
  },
  {
    id: 4,
    title: "夜行列车",
    location: "四川 · 成昆线",
    color: "#7a6f9e",
  },
];
