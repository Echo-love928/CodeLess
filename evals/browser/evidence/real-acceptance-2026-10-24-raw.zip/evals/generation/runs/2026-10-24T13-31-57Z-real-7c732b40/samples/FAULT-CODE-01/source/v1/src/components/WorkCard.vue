<script setup lang="ts">
interface WorkCardProps {
  title: string;
  description: string;
}

defineProps<WorkCardProps>();
</script>

<template>
  <article class="work-card">
    <h3 class="work-card__title">{{ title }}</h3>
    <p class="work-card__description">{{ description }}</p>
  </article>
</template>

<style scoped>
.work-card {
  flex: 1 1 240px;
  padding: 1.25rem;
  border: 1px solid #d8dde3;
  border-radius: 10px;
  background: #ffffff;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
}

.work-card__title {
  margin: 0 0 0.5rem;
  font-size: 1.1rem;
  color: #1f2933;
}

.work-card__description {
  margin: 0;
  font-size: 0.95rem;
  line-height: 1.6;
  color: #52606d;
}
</style>
