<script setup lang="ts">
import { ref } from "vue";
import WorksGallery from "../components/WorksGallery.vue";

type SectionKey = "about" | "works" | "contact";

const activeSection = ref<SectionKey>("about");
const email = "linxia@example.com";
</script>

<template>
  <main class="page">
    <header class="hero">
      <h1 class="site-title">林夏 · 摄影师作品集</h1>
      <nav class="nav" aria-label="主导航">
        <button
          type="button"
          class="nav-button"
          :class="{ active: activeSection === 'about' }"
          data-testid="nav-about"
          @click="activeSection = 'about'"
        >
          关于我
        </button>
        <button
          type="button"
          class="nav-button"
          :class="{ active: activeSection === 'works' }"
          data-testid="nav-works"
          @click="activeSection = 'works'"
        >
          作品集
        </button>
        <button
          type="button"
          class="nav-button"
          :class="{ active: activeSection === 'contact' }"
          data-testid="nav-contact"
          @click="activeSection = 'contact'"
        >
          联系方式
        </button>
      </nav>
    </header>

    <section v-if="activeSection === 'about'" class="panel" data-testid="section-about">
      <h2 class="panel-title">关于我</h2>
      <p class="panel-text">
        我是林夏，一名专注于自然与城市纪实的摄影师。镜头是我的第二语言，我习惯在清晨与夜色之间行走，记录山川、老街与海风中稍纵即逝的光。
      </p>
    </section>

    <section v-else-if="activeSection === 'works'" class="panel" data-testid="section-works">
      <h2 class="panel-title">作品集</h2>
      <WorksGallery />
    </section>

    <section v-else class="panel" data-testid="section-contact">
      <h2 class="panel-title">联系方式</h2>
      <p class="panel-text">约拍与合作请联系：</p>
      <p class="contact-email" data-testid="contact-email">{{ email }}</p>
    </section>
  </main>
</template>

<style scoped>
.page {
  max-width: 960px;
  margin: 0 auto;
  padding: 40px 20px 60px;
  font-family: "Helvetica Neue", Arial, sans-serif;
  color: #1d2433;
}

.hero {
  margin-bottom: 28px;
}

.site-title {
  font-size: 26px;
  margin: 0 0 18px;
}

.nav {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.nav-button {
  padding: 9px 20px;
  border: 1px solid #c9d1dd;
  border-radius: 999px;
  background: #ffffff;
  color: #1d2433;
  font-size: 15px;
  cursor: pointer;
}

.nav-button.active {
  background: #1d2433;
  border-color: #1d2433;
  color: #ffffff;
}

.panel {
  background: #f7f9fc;
  border-radius: 14px;
  padding: 24px;
}

.panel-title {
  margin: 0 0 14px;
  font-size: 20px;
}

.panel-text {
  margin: 0 0 12px;
  line-height: 1.8;
  color: #4b5563;
}

.contact-email {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  color: #1d2433;
}
</style>
