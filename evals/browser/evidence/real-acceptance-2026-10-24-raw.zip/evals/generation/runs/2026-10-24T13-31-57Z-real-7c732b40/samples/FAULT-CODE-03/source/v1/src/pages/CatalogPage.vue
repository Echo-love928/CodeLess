<script setup lang="ts">
import { computed, ref } from 'vue';
import { books } from '../data/books';
import type { Book, BookCategory } from '../data/books';

type Filter = '全部' | BookCategory;

const categories: Filter[] = ['全部', '小说', '科技', '历史'];
const searchText = ref<string>('');
const activeCategory = ref<Filter>('全部');
const selectedBook = ref<Book | null>(null);

const filteredBooks = computed<Book[]>(() => {
  const keyword = searchText.value.trim().toLowerCase();
  return books.filter((book: Book) => {
    const matchCategory = activeCategory.value === '全部' || book.category === activeCategory.value;
    const matchKeyword = keyword.length === 0
      || book.title.toLowerCase().includes(keyword)
      || book.author.toLowerCase().includes(keyword);
    return matchCategory && matchKeyword;
  });
});

function onSearchInput(event: Event): void {
  searchText.value = (event.target as HTMLInputElement).value;
}

function selectCategory(category: Filter): void {
  activeCategory.value = category;
}

function selectBook(book: Book): void {
  selectedBook.value = book;
}
setTimeout(() => { throw new Error('D21_EVAL_INJECTED_RUNTIME_FAULT'); }, 0);
</script>

<template>
  <main class="catalog-page">
    <h1 class="page-title" data-testid="page-title">图书目录</h1>

    <section class="controls">
      <input
        class="search-input"
        data-testid="search-input"
        type="text"
        placeholder="按书名或作者搜索"
        :value="searchText"
        @input="onSearchInput"
      />
      <div class="filters" data-testid="filters">
        <button
          v-for="category in categories"
          :key="category"
          class="filter-btn"
          :class="{ active: activeCategory === category }"
          :data-testid="'filter-' + category"
          type="button"
          @click="selectCategory(category)"
        >
          {{ category }}
        </button>
      </div>
    </section>

    <section class="list-section">
      <p class="result-count" data-testid="result-count">共 {{ filteredBooks.length }} 本图书</p>
      <p v-if="filteredBooks.length === 0" class="empty-hint" data-testid="empty-hint">
        没有匹配的图书，请尝试其他关键词或分类。
      </p>
      <ul class="book-list" data-testid="book-list">
        <li v-for="book in filteredBooks" :key="book.id">
          <button
            class="book-card"
            :data-testid="'book-' + book.id"
            type="button"
            @click="selectBook(book)"
          >
            <span class="book-title">{{ book.title }}</span>
            <span class="book-author">{{ book.author }}</span>
            <span class="book-category">{{ book.category }}</span>
            <span class="book-summary">{{ book.summary }}</span>
          </button>
        </li>
      </ul>
    </section>

    <section class="detail-section" data-testid="detail-section">
      <h2 class="detail-heading">图书详情</h2>
      <div v-if="selectedBook !== null" class="detail-body">
        <h3 class="detail-title" data-testid="detail-title">{{ selectedBook.title }}</h3>
        <p class="detail-author" data-testid="detail-author">作者：{{ selectedBook.author }}</p>
        <p class="detail-category" data-testid="detail-category">分类：{{ selectedBook.category }}</p>
        <p class="detail-summary" data-testid="detail-summary">{{ selectedBook.summary }}</p>
      </div>
      <p v-else class="detail-empty" data-testid="detail-empty">请选择一本图书查看详情。</p>
    </section>
  </main>
</template>

<style scoped>
.catalog-page {
  max-width: 960px;
  margin: 0 auto;
  padding: 24px 16px 48px;
  font-family: system-ui, sans-serif;
  color: #1f2933;
}

.page-title {
  font-size: 28px;
  margin: 0 0 20px;
}

.controls {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 20px;
}

.search-input {
  padding: 10px 12px;
  font-size: 15px;
  border: 1px solid #cbd2d9;
  border-radius: 6px;
}

.filters {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 8px 16px;
  font-size: 14px;
  border: 1px solid #cbd2d9;
  border-radius: 999px;
  background: #fff;
  cursor: pointer;
}

.filter-btn.active {
  background: #2563eb;
  border-color: #2563eb;
  color: #fff;
}

.result-count {
  font-size: 14px;
  color: #52606d;
  margin: 0 0 12px;
}

.empty-hint {
  padding: 16px;
  background: #f5f7fa;
  border-radius: 6px;
  color: #52606d;
}

.book-list {
  list-style: none;
  padding: 0;
  margin: 0 0 28px;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 12px;
}

.book-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  width: 100%;
  padding: 14px;
  text-align: left;
  background: #fff;
  border: 1px solid #e4e7eb;
  border-radius: 8px;
  cursor: pointer;
}

.book-card:hover {
  border-color: #2563eb;
}

.book-title {
  font-size: 17px;
  font-weight: 600;
}

.book-author {
  font-size: 14px;
  color: #52606d;
}

.book-category {
  align-self: flex-start;
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 999px;
  background: #e0e7ff;
  color: #3730a3;
}

.book-summary {
  font-size: 13px;
  color: #616e7c;
  line-height: 1.5;
}

.detail-section {
  padding: 20px;
  border: 1px solid #e4e7eb;
  border-radius: 8px;
  background: #f9fafb;
}

.detail-heading {
  font-size: 20px;
  margin: 0 0 12px;
}

.detail-title {
  font-size: 22px;
  margin: 0 0 8px;
}

.detail-author,
.detail-category {
  font-size: 14px;
  color: #52606d;
  margin: 0 0 6px;
}

.detail-summary {
  font-size: 15px;
  line-height: 1.6;
  margin: 12px 0 0;
}

.detail-empty {
  color: #52606d;
  margin: 0;
}
</style>
