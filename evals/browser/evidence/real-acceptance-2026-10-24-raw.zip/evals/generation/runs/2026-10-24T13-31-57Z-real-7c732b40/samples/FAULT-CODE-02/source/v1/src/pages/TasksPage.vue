<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { loadTasks, saveTasks, type Task } from '../data/tasks';

const tasks = ref<Task[]>([]);
const newTitle = ref('');

const remainingCount = computed<number>(() => tasks.value.filter((task) => !task.done).length);

function persist(): void {
  saveTasks(tasks.value);
}

function addTask(): void {
  const title = newTitle.value.trim();
  if (title === '') return;
  tasks.value.push({
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title,
    done: false,
  });
  newTitle.value = '';
  persist();
}

function toggleTask(task: Task): void {
  task.done = !task.done;
  persist();
}

function removeTask(id: string): void {
  tasks.value = tasks.value.filter((task) => task.id !== id);
  persist();
}

onMounted(() => {
  tasks.value = loadTasks();
});
const d21EvalInjectedCount: number = 'D21 injected type fault';
</script>

<template>
  <main class="tasks-page">
    <h1>个人待办清单</h1>
    <p class="remaining" data-testid="remaining-count">未完成：{{ remainingCount }}</p>

    <form class="add-form" @submit.prevent="addTask">
      <input
        v-model="newTitle"
        class="task-input"
        type="text"
        placeholder="输入任务标题"
        data-testid="task-input"
      />
      <button type="submit" class="add-button" data-testid="add-button">添加</button>
    </form>

    <p v-if="tasks.length === 0" class="empty" data-testid="empty-state">暂无任务</p>

    <ul v-else class="task-list">
      <li v-for="task in tasks" :key="task.id" class="task-item" :data-testid="`task-item-${task.id}`">
        <label class="task-label">
          <input
            type="checkbox"
            :checked="task.done"
            :data-testid="`task-checkbox-${task.id}`"
            @change="toggleTask(task)"
          />
          <span class="task-title" :class="{ done: task.done }" :data-testid="`task-title-${task.id}`">{{ task.title }}</span>
        </label>
        <button
          type="button"
          class="delete-button"
          :data-testid="`task-delete-${task.id}`"
          @click="removeTask(task.id)"
        >
          删除
        </button>
      </li>
    </ul>
  </main>
</template>

<style scoped>
.tasks-page {
  max-width: 640px;
  margin: 0 auto;
  padding: 24px 16px;
  font-family: sans-serif;
}

h1 {
  font-size: 24px;
  margin-bottom: 12px;
}

.remaining {
  color: #555;
  margin-bottom: 16px;
}

.add-form {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.task-input {
  flex: 1;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
}

.add-button,
.delete-button {
  padding: 8px 14px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

.add-button {
  background: #2563eb;
  color: #fff;
}

.delete-button {
  background: #f3f4f6;
  color: #b91c1c;
}

.task-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.task-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.task-label {
  display: flex;
  align-items: center;
  gap: 10px;
  cursor: pointer;
}

.task-title.done {
  text-decoration: line-through;
  color: #9ca3af;
}

.empty {
  color: #888;
}
</style>
