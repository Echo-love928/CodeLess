# D21-A 生成评测报告 2026-10-24T13-31-57Z-real-7c732b40

由 `scripts/eval/report.mjs#v2` 从本目录原始记录生成；`node scripts/eval/report.mjs <batchDir> --check` 可复算。

- 模式：**REAL**（REAL_MODEL）；真实模型证据：是
- Provider：deepseek / deepseek-flash；其他 provider 调用：0
- 平台提交：`0d831a7730c7df542961553a2e68e41bf84b858e`（DETACHED_WORKTREE_AT_HEAD）
- 冻结集：requirements sha256:ef219f3e5c0f05f3ab03ec854c66b32709349f80d1e1aee0076fe19d2b91cb2a，faults sha256:4b147818de5823b2ba3011cc65f57a08f63270154aa01289af8e7631c8790b13，run-config sha256:6dc271c657cdb29e72ec052621fc2633ac5d82b8d8d963bfbffccd0d929cb054
- 完成度：计划 14，已启动 14，原始记录 14，批次完成 是，凭据出现次数 0

## 9 个需求（分母固定为冻结计划）

- 首轮成功（首次真实构建+浏览器即通过、0 次修复）：**0/9**（0.0%）
- 3 轮内最终成功（平台 READY）：**0/9**（0.0%）；目标 ≥8/9：未达到（基线目标，不是既有成绩）
- 需求级最终成功（叠加 D21-B 行为断言）：PENDING_D21_B，当前为未知，不计为成功
- 缺失记录：无；harness 错误：无；样本进程异常（不计成功）：无
- 修复：共 0 轮，0 个样本发生修复
- 实际 token：159901；输入 141092 / 输出 18809；已知下限 输入 141092 / 输出 18809；缓存命中（已含在输入中）105856
- 运行时预算计费（含保守估算，非实际用量）：159901，估算调用 0
- 模型请求 45，工具槽 42；耗时中位数 27.7 s，最大 38.6 s（已知 9，未知 0）
- 失败类型：MODEL_OUTPUT×3，BUDGET×2，ENVIRONMENT×3，UNCLASSIFIED×1

| 需求 | 类别 | 任务 ID | 首次验证 | 最终 | 修复轮 | 失败类型 / 代码 | 模型请求 | 实际 token | 耗时 |
| --- | --- | --- | --- | --- | ---: | --- | ---: | --- | ---: |
| SHOW-01 | SHOWCASE | b2e02685-e776-4ef0-9367-ab5830f98b42 | FAILED | FAILED | 0 | ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE | 4 | 11831 | 28.2 s |
| SHOW-02 | SHOWCASE | 40f135a2-94ce-4bd2-9195-3689f16218e3 | FAILED | FAILED | 0 | ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE | 6 | 18927 | 26.9 s |
| SHOW-03 | SHOWCASE | 3dc78e51-b53a-4dae-9969-3c8ced199006 | FAILED | FAILED | 0 | UNCLASSIFIED / AGENT_INTERNAL_ERROR | 8 | 30933 | 38.6 s |
| TASK-01 | TASKS | 75f4e37a-2295-4f0b-ae78-b1bfc06d6333 | NONE | FAILED | 0 | MODEL_OUTPUT / AGENT_ACCEPTANCE_INVALID | 4 | 13230 | 14.8 s |
| TASK-02 | TASKS | 532620e3-19ea-46e6-a734-12d369cc007a | NONE | FAILED | 0 | MODEL_OUTPUT / PLAN_INVALID | 1 | 1896 | 4.1 s |
| TASK-03 | TASKS | 9fcf46bc-4ed6-45b0-bc8e-c4edece24212 | NONE | FAILED | 0 | BUDGET / AGENT_MODEL_BUDGET_EXCEEDED | 7 | 26820 | 27.7 s |
| CAT-01 | CATALOG | ab8f4eae-05cc-45a0-ae26-3dff182bc0f9 | FAILED | FAILED | 0 | ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE | 6 | 23309 | 31.6 s |
| CAT-02 | CATALOG | 3173aee9-810f-4118-9aaf-3f2941227126 | NONE | FAILED | 0 | BUDGET / AGENT_MODEL_BUDGET_EXCEEDED | 7 | 28164 | 30.9 s |
| CAT-03 | CATALOG | 72a11cdc-44d5-4dd5-b1c8-6c665396a5db | NONE | FAILED | 0 | MODEL_OUTPUT / MODEL_INVALID_RESPONSE | 2 | 4791 | 7.1 s |

## 故障集（与 9 个需求分开统计）

- 代码故障按预期修复：**0/3**；环境故障按预期停止：**2/2**
- 故障集实际 token：≥84590（1 次未知）

### FAULT-CODE-01（CODE / MISSING_MODULE_IMPORT，基于 SHOW-01）：FAILED

任务 1cea2fcd-d25e-46b4-9470-0508f3e1fa35；最终 FAILED；修复轮 0；失败 ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "INFRASTRUCTURE" | **未通过** |
| first decision | "REPAIR" | "AGENT_RUNNER_UNAVAILABLE" | **未通过** |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 0 | **未通过** |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | false | **未通过** |

### FAULT-CODE-02（CODE / STRICT_TYPE_ERROR，基于 TASK-01）：FAILED

任务 1290e4f6-3ee9-4ac6-bd3d-682197434e96；最终 FAILED；修复轮 0；失败 ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "INFRASTRUCTURE" | **未通过** |
| first decision | "REPAIR" | "AGENT_RUNNER_UNAVAILABLE" | **未通过** |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 0 | **未通过** |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | false | **未通过** |

### FAULT-CODE-03（CODE / RUNTIME_ASYNC_PAGE_EXCEPTION，基于 CAT-01）：FAILED

任务 42c1d068-b8c4-45d2-bc0a-b3dc3a77e815；最终 FAILED；修复轮 0；失败 ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "INFRASTRUCTURE" | **未通过** |
| first decision | "REPAIR" | "AGENT_RUNNER_UNAVAILABLE" | **未通过** |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 0 | **未通过** |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | false | **未通过** |

### FAULT-ENV-01（ENVIRONMENT / CONTAINER_CLI_UNAVAILABLE，基于 SHOW-02）：PASSED

任务 789a4162-812d-41c3-b1b4-08d93e4c79b5；最终 FAILED；修复轮 0；失败 ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| container CLI absent in sample JVM | false | false | 通过 |
| final | "FAILED" | "FAILED" | 通过 |
| failure stage | "VERIFY" | "VERIFY" | 通过 |
| failure category | "INFRASTRUCTURE" | "INFRASTRUCTURE" | 通过 |
| no REPAIR decision | true | true | 通过 |
| repair rounds | 0 | 0 | 通过 |
| REPAIR model calls | 0 | 0 | 通过 |
| immutable candidates | 1 | 1 | 通过 |
| file tool calls after failure | 0 | 0 | 通过 |

### FAULT-ENV-02（ENVIRONMENT / MODEL_ENDPOINT_UNREACHABLE，基于 TASK-02）：PASSED

任务 55d05b39-662b-44a3-929f-9c09697a878b；最终 FAILED；修复轮 0；失败 MODEL_TRANSPORT / MODEL_NETWORK

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| proxy route refused before task | "REFUSED" | "REFUSED" | 通过 |
| final | "FAILED" | "FAILED" | 通过 |
| failure code | "MODEL_NETWORK" | "MODEL_NETWORK" | 通过 |
| failure category | "MODEL_INTERFACE" | "MODEL_INTERFACE" | 通过 |
| model calls (no retry) | 1 | 1 | 通过 |
| failed call usage | "UNKNOWN" | "UNKNOWN" | 通过 |
| file tool calls | 0 | 0 | 通过 |
| repair rounds | 0 | 0 | 通过 |

## 一致性核对

评测计算的模型请求数、工具槽与预算计费均与平台日志计量一致。


## 输入文件摘要

- `batch-complete.json` sha256:f51957603f2d1688759f3f3e7e0468d953bade1037eb821f8385bdfa8dd4e41e
- `batch.json` sha256:3586f75d6c32662265d81f45c6425266b0778b80c08ef64483709e4ee96d27d7
- `frozen/faults.json` sha256:4b147818de5823b2ba3011cc65f57a08f63270154aa01289af8e7631c8790b13
- `frozen/requirements.json` sha256:ef219f3e5c0f05f3ab03ec854c66b32709349f80d1e1aee0076fe19d2b91cb2a
- `frozen/runConfig.json` sha256:6dc271c657cdb29e72ec052621fc2633ac5d82b8d8d963bfbffccd0d929cb054
- `samples/CAT-01/invocation-result.json` sha256:7746808971c3c1cf751e27a77ab8d882e4d2f18d942816515be5ec580ac8e976
- `samples/CAT-01/record.json` sha256:dd9789d1479f1fba73ca05ecdaf89d11b4e1c15ddddecd39f5f3513d2e286293
- `samples/CAT-01/spec.json` sha256:9f09ea46f8e0a5d5449749c6e8fb5255d396f38d571f6bd47d17abfc97c4b3e7
- `samples/CAT-02/invocation-result.json` sha256:8f9ede63e41f5dd660d36d51ff87ff66ce790ce0e086442e28e19729f4f5002c
- `samples/CAT-02/record.json` sha256:3f6c02e92cb2a1afb09d306877b9e02d20372c4547fde34dd2c8d52b7fa43bda
- `samples/CAT-02/spec.json` sha256:55267fed736f182b0f28c0a548cd68425646b5b3c9845bfc72b2256122260b05
- `samples/CAT-03/invocation-result.json` sha256:2d57aa04018501a9a74811cc646a47c0a7a709d9ace327f6617a58f79cb389f3
- `samples/CAT-03/record.json` sha256:06533707e45bbe22ed024f025c4873d505bd6703634a5993c99c2b1972e61240
- `samples/CAT-03/spec.json` sha256:895a7293cc082d0b3fda04bbc434fb806e855835155c9cca8ba2cba0a7f2f449
- `samples/FAULT-CODE-01/invocation-result.json` sha256:a5ecf136d75c0cb72845f04023e3a9f697c0fecae90638d3191e78d4b8a74c3d
- `samples/FAULT-CODE-01/record.json` sha256:7a01119dfe089f28ab2088d2428b734dc812accab15e4dea820ec57925775c00
- `samples/FAULT-CODE-01/spec.json` sha256:14e3a54802e4ddf3263305c80214398d5a0ac2f6147ff93e902c808c8606858e
- `samples/FAULT-CODE-02/invocation-result.json` sha256:05bb1c2c251b098e92b3730884ac1bb50468a8fd94116228158b359d13f65f33
- `samples/FAULT-CODE-02/record.json` sha256:862c83adb5d805855e28a1c21a29700aa0aab0ec117fac34f3aeea36cb5e0dbe
- `samples/FAULT-CODE-02/spec.json` sha256:380bbd51755453a681b1cad0b2a357c3fca79cd94d043d261fd678b3d6305504
- `samples/FAULT-CODE-03/invocation-result.json` sha256:9ba5161b9d5c77537ea4e82250ba34560fdca3bfd478434d9a69b5bedae9bed6
- `samples/FAULT-CODE-03/record.json` sha256:91ff6f22781cccd3dfc53f46151026e0e141c4d1b88ac05f768c9aba237efaf5
- `samples/FAULT-CODE-03/spec.json` sha256:1683f5c826a040a74011a1229cbe6840a1cc62d296b52abc9a8a87f4553938d4
- `samples/FAULT-ENV-01/invocation-result.json` sha256:94bffc315f8bfbc2dea1609c4cc6f74b44020a334916e963e075a2767104094d
- `samples/FAULT-ENV-01/record.json` sha256:cff44ef4b960fa798c142c8046e5a5782c51e0bb1805786eac5db3b1518da706
- `samples/FAULT-ENV-01/spec.json` sha256:999453e0c41dfa8699bc6db75f64ec53b9f9321747addb98e1beeecc429ee1c1
- `samples/FAULT-ENV-02/invocation-result.json` sha256:31e1971dcdf5be374dd407f77170cc08063774346eda15985c5ecfe0ce139aca
- `samples/FAULT-ENV-02/record.json` sha256:607f906a68c1ea495357c19a0235cb03e0a652b02f3f8476f8233482c01163fa
- `samples/FAULT-ENV-02/spec.json` sha256:9cbe87f8f6d9e001d17b874689cbe62f689addc335b8824c1614bc0b96af74cb
- `samples/SHOW-01/invocation-result.json` sha256:e749a3348cce409142dfb077c2732a8c8cbfdd6129195e072cc6974e5cea8161
- `samples/SHOW-01/record.json` sha256:5eec51c994e75f2a75aec3858f87ab4903d4eb25f18f6568792c7ece1b508f9d
- `samples/SHOW-01/spec.json` sha256:344142c872dddb80a10938dc3e69389fac1ea03be014c2050f613dcb933c4b92
- `samples/SHOW-02/invocation-result.json` sha256:3439d8d13f452d591ee90a78aa793914ada57e61e628ec85da6772c338fce38f
- `samples/SHOW-02/record.json` sha256:7fb887432e835f274cb0b57e6289d42d16a04b18e3a9319d903d2ed89efc3be1
- `samples/SHOW-02/spec.json` sha256:0504d06158cc2faaaf6e1e499b5fd22f010eb480a4e204baf70b25ca725cb2af
- `samples/SHOW-03/invocation-result.json` sha256:fe882716197113152087b325862f84a8715c56ccc7b13070d004d0bbb3f0ce24
- `samples/SHOW-03/record.json` sha256:6d6d198268b4c086912970f7e6d2cca069a5bce7478392dd6975cb3d2604624f
- `samples/SHOW-03/spec.json` sha256:fd4ff81b2606476dc4117727e1c8e5e57bb14028a94f052ff9b6f6bbfc3aff92
- `samples/TASK-01/invocation-result.json` sha256:83ab71c7e3a9bcd94e2b8b4409e66eefd05726fbd22aa0506c611bf23f8b8efd
- `samples/TASK-01/record.json` sha256:667fd5fc2184f9e959b22da6767a834f42f1bbeadb76c5f9a6c81bf691576589
- `samples/TASK-01/spec.json` sha256:8827d58551e39ee11dec799462027a9091b8614fef0c3778f947fcee5d159ee9
- `samples/TASK-02/invocation-result.json` sha256:656fdd8b053920a8733a6623b782ee352960c7544217e78c41b6f2554f87f53a
- `samples/TASK-02/record.json` sha256:cfe95e05425d61a1d9156fe769489277ce62cfc6cdf0e9b96fdb1147b1fbfed2
- `samples/TASK-02/spec.json` sha256:1b414680c65e4de25ffcda37e6341a30500e149328b3feacceac09a1cd9e6317
- `samples/TASK-03/invocation-result.json` sha256:d7bc1f2506a381187bd597cae5234e2a81069dcb16964df8adba744dd2556dde
- `samples/TASK-03/record.json` sha256:a54a20f8d734b7f448cc5f5f2471ce8376ba5c3e5bebf7c7362ab256b1039cd9
- `samples/TASK-03/spec.json` sha256:498bf48bffc898e029091df4c2d4814879845ea28800d8eece849abef9b1fe01
