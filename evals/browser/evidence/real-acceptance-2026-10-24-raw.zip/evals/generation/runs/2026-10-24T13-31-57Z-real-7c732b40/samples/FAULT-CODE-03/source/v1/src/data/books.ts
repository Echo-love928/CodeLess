export type BookCategory = '小说' | '科技' | '历史';

export interface Book {
  id: number;
  title: string;
  author: string;
  category: BookCategory;
  summary: string;
}

export const books: Book[] = [
  {
    id: 1,
    title: '百年孤独',
    author: '加西亚·马尔克斯',
    category: '小说',
    summary: '布恩迪亚家族七代人的传奇故事，魔幻现实主义的经典之作。',
  },
  {
    id: 2,
    title: '活着',
    author: '余华',
    category: '小说',
    summary: '讲述农民福贵历经苦难仍坚韧活着的一生。',
  },
  {
    id: 3,
    title: '深入理解计算机系统',
    author: '兰德尔·布莱恩特',
    category: '科技',
    summary: '从程序员视角剖析计算机系统的底层原理与实践。',
  },
  {
    id: 4,
    title: '算法导论',
    author: '托马斯·科尔曼',
    category: '科技',
    summary: '系统全面地介绍算法设计与分析的权威教材。',
  },
  {
    id: 5,
    title: '人类简史',
    author: '尤瓦尔·赫拉利',
    category: '历史',
    summary: '从认知革命到科学革命，梳理人类文明的发展脉络。',
  },
  {
    id: 6,
    title: '万历十五年',
    author: '黄仁宇',
    category: '历史',
    summary: '以一个年份为切口，透视明代社会的结构性困局。',
  },
  {
    id: 7,
    title: '三体',
    author: '刘慈欣',
    category: '小说',
    summary: '人类文明与三体文明相遇后的宏大科幻史诗。',
  },
  {
    id: 8,
    title: '代码大全',
    author: '史蒂夫·麦康奈尔',
    category: '科技',
    summary: '软件构建实践的百科全书，提升代码质量的指南。',
  },
];
