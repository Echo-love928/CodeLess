export interface Work {
  id: string;
  title: string;
  description: string;
}

export const works: Work[] = [
  {
    id: 'mark-i',
    title: 'Harvard Mark I 编程',
    description: '为早期大型计算机 Harvard Mark I 编写程序，奠定了现代编程实践的基础。',
  },
  {
    id: 'a-0',
    title: 'A-0 编译器',
    description: '开发了最早的编译器之一 A-0，让计算机能够理解符号化的程序指令。',
  },
  {
    id: 'cobol',
    title: 'COBOL 标准化',
    description: '推动 COBOL 语言的设计与标准化，使商业数据处理更加普及和可靠。',
  },
];

export const contactEmail = 'grace.hopper@example.com';
