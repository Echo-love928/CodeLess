<script setup lang="ts">
import D21EvalMissingPanel from '../components/D21EvalMissingPanel.vue';
import WorkCard from '../components/WorkCard.vue';
import { works, contactEmail } from '../data/works';
</script>

<template>
  <main class="home">
    <header class="home__header">
      <h1 class="home__name" data-testid="profile-name">Grace Hopper</h1>
      <p class="home__intro" data-testid="profile-intro">计算机科学先驱，COBOL 语言的推动者</p>
    </header>

    <section class="home__works" data-testid="works-section">
      <WorkCard
        v-for="work in works"
        :key="work.id"
        :title="work.title"
        :description="work.description"
      />
    </section>

    <footer class="home__footer">
      <p class="home__email" data-testid="contact-email">{{ contactEmail }}</p>
    </footer>
  </main>
</template>

<style scoped>
.home {
  max-width: 960px;
  margin: 0 auto;
  padding: 2rem 1.5rem 3rem;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
}

.home__header {
  text-align: center;
  padding: 2rem 0;
  border-bottom: 1px solid #e4e7eb;
}

.home__name {
  margin: 0 0 0.75rem;
  font-size: 2rem;
  color: #102a43;
}

.home__intro {
  margin: 0;
  font-size: 1.05rem;
  color: #52606d;
}

.home__works {
  display: flex;
  flex-wrap: wrap;
  gap: 1.25rem;
  margin: 2.5rem 0;
}

.home__footer {
  margin-top: 2.5rem;
  padding-top: 1.5rem;
  border-top: 1px solid #e4e7eb;
  text-align: center;
}

.home__email {
  margin: 0;
  font-size: 0.95rem;
  color: #3e4c59;
}
</style>
