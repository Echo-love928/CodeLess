<script setup lang="ts">
import { computed, ref } from 'vue';
import { books } from '../data/books';
import type { Book, BookCategory } from '../data/books';

type FilterCategory = '全部' | BookCategory;

const searchQuery = ref<string>('');
const activeCategory = ref<FilterCategory>('全部');
const selectedBook = ref<Book | null>(null);

const categories: FilterCategory[] = ['全部', '小说', '科技', '历史'];

const filteredBooks = computed<Book[]>(() => {
  const query = searchQuery.value.trim().toLowerCase();
  return books.filter((book: Book) => {
    const matchesCategory =
      activeCategory.value === '全部' || book.category === activeCategory.value;
    const matchesQuery =
      query === '' ||
      book.title.toLowerCase().includes(query) ||
      book.author.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });
});

function selectCategory(category: FilterCategory): void {
  activeCategory.value = category;
}

function selectBook(book: Book): void {
  selectedBook.value = book;
}
</script>

<template>
  <div class="catalog-page">
    <h1 class="page-title">图书目录</h1>

    <div class="search-bar">
      <label class="search-label" for="search-input">搜索</label>
      <input
        id="search-input"
        v-model="searchQuery"
        class="search-input"
        type="text"
        placeholder="按书名或作者搜索"
        data-testid="search-input"
      />
    </div>

    <div class="filter-bar">
      <button
        v-for="category in categories"
        :key="category"
        type="button"
        class="filter-btn"
        :class="{ active: activeCategory === category }"
        :data-testid="`filter-${category}`"
        @click="selectCategory(category)"
      >
        {{ category }}
      </button>
    </div>

    <p class="result-count" data-testid="result-count">共 {{ filteredBooks.length }} 本图书</p>

    <div class="content-layout">
      <ul class="book-list" data-testid="book-list">
        <li
          v-for="book in filteredBooks"
          :key="book.id"
          class="book-item"
          :class="{ selected: selectedBook !== null && selectedBook.id === book.id }"
          :data-testid="`book-${book.id}`"
          @click="selectBook(book)"
        >
          <span class="book-title">{{ book.title }}</span>
          <span class="book-author">{{ book.author }}</span>
          <span class="book-category">{{ book.category }}</span>
        </li>
      </ul>

      <section class="detail-panel" data-testid="book-detail">
        <template v-if="selectedBook">
          <h2 class="detail-title" data-testid="detail-title">{{ selectedBook.title }}</h2>
          <p class="detail-author" data-testid="detail-author">作者：{{ selectedBook.author }}</p>
          <p class="detail-category" data-testid="detail-category">分类：{{ selectedBook.category }}</p>
          <p class="detail-summary" data-testid="detail-summary">{{ selectedBook.summary }}</p>
        </template>
        <p v-else class="detail-empty" data-testid="detail-empty">点击左侧图书查看详情</p>
      </section>
    </div>
  </div>
</template>

<style scoped>
.catalog-page {
  max-width: 960px;
  margin: 0 auto;
  padding: 24px 16px 48px;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  color: #1f2933;
}

.page-title {
  font-size: 26px;
  margin-bottom: 20px;
}

.search-bar {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.search-label {
  font-size: 14px;
  color: #52606d;
}

.search-input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #cbd2d9;
  border-radius: 6px;
  font-size: 14px;
}

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
}

.filter-btn {
  padding: 6px 16px;
  border: 1px solid #cbd2d9;
  border-radius: 999px;
  background: #fff;
  color: #334155;
  cursor: pointer;
  font-size: 14px;
}

.filter-btn.active {
  background: #2563eb;
  border-color: #2563eb;
  color: #fff;
}

.result-count {
  font-size: 13px;
  color: #66788a;
  margin-bottom: 16px;
}

.content-layout {
  display: flex;
  gap: 20px;
  align-items: flex-start;
}

.book-list {
  list-style: none;
  margin: 0;
  padding: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.book-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border: 1px solid #e4e7eb;
  border-radius: 8px;
  cursor: pointer;
  background: #fff;
}

.book-item.selected {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.15);
}

.book-title {
  font-weight: 600;
  min-width: 120px;
}

.book-author {
  color: #52606d;
  flex: 1;
}

.book-category {
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 999px;
  background: #eef2ff;
  color: #3730a3;
}

.detail-panel {
  width: 280px;
  padding: 16px;
  border: 1px solid #e4e7eb;
  border-radius: 8px;
  background: #f8fafc;
}

.detail-title {
  font-size: 20px;
  margin: 0 0 12px;
}

.detail-author,
.detail-category {
  font-size: 14px;
  margin: 0 0 8px;
  color: #52606d;
}

.detail-summary {
  font-size: 14px;
  line-height: 1.6;
  margin: 12px 0 0;
}

.detail-empty {
  font-size: 14px;
  color: #9aa5b1;
  margin: 0;
}
</style>
