<script setup lang="ts">
interface WorkCard {
  title: string;
  description: string;
}

const name = 'Grace Hopper';
const intro = '计算机科学先驱，COBOL 语言的推动者';
const email = 'grace.hopper@example.com';

const works: WorkCard[] = [
  {
    title: 'Harvard Mark I 编程',
    description: '为 Harvard Mark I 早期计算机编写程序并参与其技术文档工作。',
  },
  {
    title: 'A-0 编译器',
    description: '提出并开发了最早的编译器之一，让机器能够理解符号化指令。',
  },
  {
    title: 'COBOL 标准化',
    description: '推动面向业务的编程语言标准化，使代码更易于编写与维护。',
  },
];
</script>

<template>
  <main class="profile">
    <header class="profile__header">
      <h1 class="profile__name" data-testid="profile-name">{{ name }}</h1>
      <p class="profile__intro" data-testid="profile-intro">{{ intro }}</p>
    </header>

    <section class="works" aria-label="代表作品">
      <ul class="works__list">
        <li
          v-for="(work, index) in works"
          :key="work.title"
          class="works__item"
          :data-testid="`work-card-${index}`"
        >
          <h2 class="works__title">{{ work.title }}</h2>
          <p class="works__desc">{{ work.description }}</p>
        </li>
      </ul>
    </section>

    <footer class="profile__footer">
      <span class="profile__email-label">联系邮箱：</span>
      <span class="profile__email" data-testid="profile-email">{{ email }}</span>
    </footer>
  </main>
</template>

<style scoped>
.profile {
  max-width: 960px;
  margin: 0 auto;
  padding: 2.5rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 2.5rem;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  color: #1f2933;
}

.profile__header {
  text-align: center;
}

.profile__name {
  margin: 0 0 0.75rem;
  font-size: 2.25rem;
  letter-spacing: 0.02em;
}

.profile__intro {
  margin: 0;
  font-size: 1.1rem;
  color: #52606d;
}

.works__list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1.5rem;
}

.works__item {
  background: #f5f7fa;
  border: 1px solid #e4e7eb;
  border-radius: 12px;
  padding: 1.5rem;
  box-shadow: 0 2px 6px rgba(15, 23, 42, 0.06);
}

.works__title {
  margin: 0 0 0.75rem;
  font-size: 1.15rem;
  color: #102a43;
}

.works__desc {
  margin: 0;
  font-size: 0.95rem;
  line-height: 1.6;
  color: #486581;
}

.profile__footer {
  text-align: center;
  padding-top: 1.5rem;
  border-top: 1px solid #e4e7eb;
  font-size: 0.95rem;
  color: #52606d;
}

.profile__email {
  font-weight: 600;
  color: #102a43;
}
</style>
