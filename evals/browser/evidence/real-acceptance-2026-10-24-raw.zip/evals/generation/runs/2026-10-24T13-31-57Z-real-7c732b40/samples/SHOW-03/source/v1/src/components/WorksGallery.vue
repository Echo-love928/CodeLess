<script setup lang="ts">
import { works } from "../data/works";
import type { Work } from "../data/works";

const items: Work[] = works;
</script>

<template>
  <div class="works-grid">
    <article
      v-for="work in items"
      :key="work.id"
      class="work-card"
      :data-testid="`work-card-${work.id}`"
    >
      <div
        class="work-swatch"
        :style="{ backgroundColor: work.color }"
        :data-testid="`work-swatch-${work.id}`"
        aria-hidden="true"
      ></div>
      <h3 class="work-title">{{ work.title }}</h3>
      <p class="work-location">{{ work.location }}</p>
    </article>
  </div>
</template>

<style scoped>
.works-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 20px;
}

.work-card {
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 6px 18px rgba(20, 25, 40, 0.08);
  padding-bottom: 14px;
}

.work-swatch {
  width: 100%;
  height: 150px;
}

.work-title {
  margin: 12px 16px 4px;
  font-size: 17px;
  color: #1d2433;
}

.work-location {
  margin: 0 16px;
  font-size: 14px;
  color: #6b7280;
}
</style>
