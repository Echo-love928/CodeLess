<script setup lang="ts">
import { ref } from 'vue';

interface ScheduleItem {
  time: string;
  title: string;
}

const eventName: string = '2026 杭州前端开发者大会';
const eventDate: string = '2026年11月20日';
const eventLocation: string = '杭州国际博览中心';

const schedule: ScheduleItem[] = [
  { time: '09:00', title: '开幕致辞' },
  { time: '10:30', title: 'Vue 性能优化实战' },
  { time: '14:00', title: '无障碍设计实践' },
];

const registered = ref<boolean>(false);

function handleRegister(): void {
  registered.value = true;
}
</script>

<template>
  <main class="event-page">
    <header class="event-header">
      <h1 class="event-name" data-testid="event-name">{{ eventName }}</h1>
      <p class="event-meta">
        <span data-testid="event-date">日期：{{ eventDate }}</span>
        <span data-testid="event-location">地点：{{ eventLocation }}</span>
      </p>
    </header>

    <section class="schedule">
      <h2 class="schedule-title">活动日程</h2>
      <ul class="schedule-list">
        <li
          v-for="(item, index) in schedule"
          :key="item.time"
          class="schedule-item"
          :data-testid="`schedule-item-${index}`"
        >
          <span class="schedule-time">{{ item.time }}</span>
          <span class="schedule-heading">{{ item.title }}</span>
        </li>
      </ul>
    </section>

    <section class="register">
      <button class="register-btn" type="button" data-testid="register-btn" @click="handleRegister">
        我要报名
      </button>
      <p v-if="registered" class="register-feedback" data-testid="register-feedback">
        报名意向已记录（演示）
      </p>
    </section>
  </main>
</template>

<style scoped>
.event-page {
  max-width: 720px;
  margin: 0 auto;
  padding: 32px 20px;
  font-family: Arial, 'Helvetica Neue', sans-serif;
  color: #1f2933;
}

.event-header {
  border-bottom: 2px solid #2c6bed;
  padding-bottom: 16px;
}

.event-name {
  margin: 0 0 12px;
  font-size: 28px;
  color: #12306b;
}

.event-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin: 0;
  font-size: 16px;
  color: #3e4c59;
}

.schedule {
  margin-top: 28px;
}

.schedule-title {
  margin: 0 0 12px;
  font-size: 20px;
}

.schedule-list {
  list-style: none;
  margin: 0;
  padding: 0;
}

.schedule-item {
  display: flex;
  gap: 16px;
  padding: 12px 16px;
  margin-bottom: 8px;
  background: #f5f7fa;
  border-left: 4px solid #2c6bed;
  border-radius: 4px;
}

.schedule-time {
  font-weight: bold;
  color: #2c6bed;
  min-width: 56px;
}

.schedule-heading {
  font-size: 16px;
}

.register {
  margin-top: 32px;
}

.register-btn {
  padding: 10px 28px;
  font-size: 16px;
  color: #ffffff;
  background: #2c6bed;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.register-btn:hover {
  background: #1f55c4;
}

.register-feedback {
  margin-top: 12px;
  font-size: 15px;
  color: #1a7f37;
}
</style>
