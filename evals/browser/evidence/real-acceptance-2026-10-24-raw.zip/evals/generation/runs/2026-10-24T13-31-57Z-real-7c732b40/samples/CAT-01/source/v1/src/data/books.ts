export type BookCategory = '小说' | '科技' | '历史';

export interface Book {
  id: number;
  title: string;
  author: string;
  category: BookCategory;
  summary: string;
}

export const books: Book[] = [
  {
    id: 1,
    title: '三体',
    author: '刘慈欣',
    category: '科技',
    summary: '人类文明与三体文明首次接触，由此展开一场跨越星海的生存博弈。'
  },
  {
    id: 2,
    title: '活着',
    author: '余华',
    category: '小说',
    summary: '农民福贵历经家庭变故与时代动荡，在苦难中坚韧地活下去。'
  },
  {
    id: 3,
    title: '明朝那些事儿',
    author: '当年明月',
    category: '历史',
    summary: '以通俗幽默的笔法讲述明朝从开国到灭亡的兴衰历程。'
  },
  {
    id: 4,
    title: '人类简史',
    author: '尤瓦尔·赫拉利',
    category: '历史',
    summary: '从认知革命到科学革命，梳理智人如何塑造今日世界。'
  },
  {
    id: 5,
    title: '百年孤独',
    author: '加西亚·马尔克斯',
    category: '小说',
    summary: '布恩迪亚家族七代人的传奇故事，折射拉美百年沧桑。'
  },
  {
    id: 6,
    title: '时间简史',
    author: '史蒂芬·霍金',
    category: '科技',
    summary: '从大爆炸到黑洞，以通俗语言探索宇宙的起源与命运。'
  },
  {
    id: 7,
    title: '万历十五年',
    author: '黄仁宇',
    category: '历史',
    summary: '以 1587 年为切面，剖析明代政治与社会的深层结构。'
  },
  {
    id: 8,
    title: '代码整洁之道',
    author: '罗伯特·C·马丁',
    category: '科技',
    summary: '讲解编写可读、可维护代码的原则与实践方法。'
  }
];
