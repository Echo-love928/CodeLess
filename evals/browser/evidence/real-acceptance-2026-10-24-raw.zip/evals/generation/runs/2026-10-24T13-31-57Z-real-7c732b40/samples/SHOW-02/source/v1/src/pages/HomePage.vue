<script setup lang="ts">
import { ref } from 'vue';
import { eventInfo } from '../data/event';

const registered = ref<boolean>(false);

function register(): void {
  registered.value = true;
}
</script>

<template>
  <main class="event-page">
    <h1 class="event-name" data-testid="event-name">{{ eventInfo.name }}</h1>
    <p class="event-date" data-testid="event-date">日期：{{ eventInfo.date }}</p>
    <p class="event-location" data-testid="event-location">地点：{{ eventInfo.location }}</p>

    <h2 class="schedule-title">活动日程</h2>
    <ul class="schedule-list">
      <li
        v-for="(item, index) in eventInfo.schedule"
        :key="item.time"
        class="schedule-item"
        :data-testid="`schedule-item-${index}`"
      >
        <span class="schedule-time">{{ item.time }}</span>
        <span class="schedule-name">{{ item.title }}</span>
      </li>
    </ul>

    <button class="register-button" type="button" data-testid="register-button" @click="register">
      我要报名
    </button>
    <p v-if="registered" class="register-message" data-testid="register-message">
      报名意向已记录（演示）
    </p>
  </main>
</template>

<style scoped>
.event-page {
  max-width: 640px;
  margin: 0 auto;
  padding: 2rem 1rem;
  font-family: system-ui, sans-serif;
  color: #1f2937;
}

.event-name {
  font-size: 1.75rem;
  margin-bottom: 1rem;
}

.event-date,
.event-location {
  margin: 0.25rem 0;
}

.schedule-title {
  margin-top: 1.5rem;
  font-size: 1.25rem;
}

.schedule-list {
  list-style: none;
  padding: 0;
}

.schedule-item {
  display: flex;
  gap: 1rem;
  padding: 0.5rem 0;
  border-bottom: 1px solid #e5e7eb;
}

.schedule-time {
  font-weight: 600;
  min-width: 4rem;
}

.register-button {
  margin-top: 1.5rem;
  padding: 0.6rem 1.5rem;
  font-size: 1rem;
  color: #ffffff;
  background-color: #2563eb;
  border: none;
  border-radius: 0.375rem;
  cursor: pointer;
}

.register-message {
  margin-top: 0.75rem;
  color: #047857;
}
</style>
