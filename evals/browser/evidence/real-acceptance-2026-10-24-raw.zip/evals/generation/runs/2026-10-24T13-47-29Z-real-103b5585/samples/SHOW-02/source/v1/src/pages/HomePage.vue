<script setup lang="ts">
import { ref } from 'vue';
import ScheduleList from '../components/ScheduleList.vue';
import { scheduleItems } from '../data/schedule';

const registered = ref<boolean>(false);

function handleRegister(): void {
  registered.value = true;
}
</script>

<template>
  <main class="event-page">
    <h1 class="event-name" data-testid="event-name">2026 杭州前端开发者大会</h1>
    <p class="event-date" data-testid="event-date">2026年11月20日</p>
    <p class="event-location" data-testid="event-location">杭州国际博览中心</p>

    <section class="schedule">
      <h2 class="schedule-heading">日程安排</h2>
      <ScheduleList :items="scheduleItems" />
    </section>

    <section class="register">
      <button type="button" class="register-button" data-testid="register-button" @click="handleRegister">
        我要报名
      </button>
      <p v-if="registered" class="register-message" data-testid="register-message">
        报名意向已记录（演示）
      </p>
    </section>
  </main>
</template>

<style scoped>
.event-page {
  max-width: 640px;
  margin: 0 auto;
  padding: 2rem 1.5rem;
  font-family: system-ui, sans-serif;
  color: #111827;
}

.event-name {
  font-size: 1.75rem;
  margin-bottom: 0.5rem;
}

.event-date,
.event-location {
  margin: 0.25rem 0;
  color: #374151;
}

.schedule {
  margin-top: 2rem;
}

.schedule-heading {
  font-size: 1.25rem;
  margin-bottom: 0.5rem;
}

.register {
  margin-top: 2rem;
}

.register-button {
  padding: 0.6rem 1.4rem;
  font-size: 1rem;
  color: #ffffff;
  background-color: #2563eb;
  border: none;
  border-radius: 0.375rem;
  cursor: pointer;
}

.register-button:hover {
  background-color: #1d4ed8;
}

.register-message {
  margin-top: 0.75rem;
  color: #047857;
}
</style>
