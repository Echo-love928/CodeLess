export interface Task {
  id: string;
  title: string;
  completed: boolean;
}

export const TASKS_STORAGE_KEY = 'personal-todo-tasks';

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS_STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }
    const tasks: Task[] = [];
    for (const item of parsed) {
      if (
        item !== null &&
        typeof item === 'object' &&
        typeof (item as Task).id === 'string' &&
        typeof (item as Task).title === 'string' &&
        typeof (item as Task).completed === 'boolean'
      ) {
        tasks.push({
          id: (item as Task).id,
          title: (item as Task).title,
          completed: (item as Task).completed,
        });
      }
    }
    return tasks;
  } catch {
    return [];
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch {
    // Ignore storage errors (e.g. quota exceeded or disabled storage).
  }
}

export function createTask(title: string): Task {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title,
    completed: false,
  };
}
