export interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  purchased: boolean;
}

export const STORAGE_KEY = 'family-shopping-list';

export function loadItems(): ShoppingItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }
    const items: ShoppingItem[] = [];
    for (const entry of parsed) {
      if (typeof entry !== 'object' || entry === null) {
        continue;
      }
      const record = entry as Record<string, unknown>;
      if (typeof record.id !== 'string' || typeof record.name !== 'string') {
        continue;
      }
      const quantity = typeof record.quantity === 'number' && record.quantity > 0 ? record.quantity : 1;
      items.push({
        id: record.id,
        name: record.name,
        quantity,
        purchased: record.purchased === true,
      });
    }
    return items;
  } catch {
    return [];
  }
}

export function saveItems(items: ShoppingItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // Ignore storage errors (quota/private mode).
  }
}

export function createItem(name: string, quantity: number): ShoppingItem {
  return {
    id: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    quantity,
    purchased: false,
  };
}
