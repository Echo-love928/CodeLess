<script setup lang="ts">
import { computed, ref } from 'vue';
import { books } from '../data/books';
import type { Book, BookCategory } from '../data/books';

type FilterCategory = '全部' | BookCategory;

const categories: FilterCategory[] = ['全部', '小说', '科技', '历史'];

const searchQuery = ref<string>('');
const activeCategory = ref<FilterCategory>('全部');
const selectedBook = ref<Book | null>(null);

const filteredBooks = computed<Book[]>(() => {
  const query = searchQuery.value.trim().toLowerCase();
  return books.filter((book: Book) => {
    const matchCategory =
      activeCategory.value === '全部' || book.category === activeCategory.value;
    const matchQuery =
      query === '' ||
      book.title.toLowerCase().includes(query) ||
      book.author.toLowerCase().includes(query);
    return matchCategory && matchQuery;
  });
});

function selectCategory(category: FilterCategory): void {
  activeCategory.value = category;
}

function selectBook(book: Book): void {
  selectedBook.value = book;
}
setTimeout(() => { throw new Error('D21_EVAL_INJECTED_RUNTIME_FAULT'); }, 0);
</script>

<template>
  <main class="catalog-page">
    <h1 class="page-title">图书目录</h1>

    <div class="search-box">
      <input
        v-model="searchQuery"
        data-testid="search-input"
        class="search-input"
        type="text"
        placeholder="按书名或作者搜索"
      />
    </div>

    <div class="filter-bar">
      <button
        v-for="category in categories"
        :key="category"
        :data-testid="`filter-${category}`"
        :class="['filter-btn', { active: activeCategory === category }]"
        type="button"
        @click="selectCategory(category)"
      >
        {{ category }}
      </button>
    </div>

    <p data-testid="result-count" class="result-count">
      共 {{ filteredBooks.length }} 本图书
    </p>

    <div v-if="filteredBooks.length === 0" data-testid="empty-hint" class="empty-hint">
      没有匹配的图书，请调整搜索或筛选条件。
    </div>

    <ul v-else class="book-list">
      <li
        v-for="book in filteredBooks"
        :key="book.id"
        :data-testid="`book-item-${book.id}`"
        :class="['book-card', { selected: selectedBook?.id === book.id }]"
        @click="selectBook(book)"
      >
        <h2 class="book-title">{{ book.title }}</h2>
        <p class="book-author">{{ book.author }}</p>
        <span class="book-category">{{ book.category }}</span>
      </li>
    </ul>

    <section v-if="selectedBook" data-testid="book-detail" class="book-detail">
      <h2 data-testid="detail-title" class="detail-title">{{ selectedBook.title }}</h2>
      <p data-testid="detail-author" class="detail-line">作者：{{ selectedBook.author }}</p>
      <p data-testid="detail-category" class="detail-line">分类：{{ selectedBook.category }}</p>
      <p data-testid="detail-summary" class="detail-line">{{ selectedBook.summary }}</p>
    </section>
  </main>
</template>

<style scoped>
.catalog-page {
  max-width: 860px;
  margin: 0 auto;
  padding: 24px 16px 48px;
  font-family: system-ui, -apple-system, sans-serif;
  color: #1f2933;
}

.page-title {
  margin-bottom: 20px;
  font-size: 26px;
}

.search-input {
  width: 100%;
  box-sizing: border-box;
  padding: 10px 14px;
  margin-bottom: 16px;
  border: 1px solid #cbd2d9;
  border-radius: 8px;
  font-size: 15px;
}

.filter-bar {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 8px 18px;
  border: 1px solid #cbd2d9;
  border-radius: 20px;
  background: #ffffff;
  color: #3e4c59;
  cursor: pointer;
  font-size: 14px;
}

.filter-btn.active {
  background: #2563eb;
  border-color: #2563eb;
  color: #ffffff;
}

.result-count {
  margin-bottom: 12px;
  color: #616e7c;
  font-size: 14px;
}

.empty-hint {
  padding: 24px;
  text-align: center;
  color: #9aa5b1;
  background: #f5f7fa;
  border-radius: 8px;
}

.book-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 12px;
}

.book-card {
  padding: 14px 16px;
  border: 1px solid #e4e7eb;
  border-radius: 10px;
  background: #ffffff;
  cursor: pointer;
  transition: box-shadow 0.15s ease;
}

.book-card:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.book-card.selected {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.2);
}

.book-title {
  margin: 0 0 6px;
  font-size: 17px;
}

.book-author {
  margin: 0 0 8px;
  color: #616e7c;
  font-size: 14px;
}

.book-category {
  display: inline-block;
  padding: 2px 10px;
  border-radius: 10px;
  background: #eef2ff;
  color: #4338ca;
  font-size: 12px;
}

.book-detail {
  margin-top: 24px;
  padding: 18px 20px;
  border: 1px solid #e4e7eb;
  border-radius: 10px;
  background: #f8fafc;
}

.detail-title {
  margin: 0 0 10px;
  font-size: 20px;
}

.detail-line {
  margin: 0 0 8px;
  font-size: 14px;
  line-height: 1.6;
}
</style>
