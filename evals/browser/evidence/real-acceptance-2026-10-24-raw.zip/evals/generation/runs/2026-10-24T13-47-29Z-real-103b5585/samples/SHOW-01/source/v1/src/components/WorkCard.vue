<script setup lang="ts">
interface Work {
  id: string;
  title: string;
  description: string;
}

defineProps<{ work: Work }>();
</script>

<template>
  <article class="work-card" :data-testid="`work-card-${work.id}`">
    <h2 class="work-card__title" :data-testid="`work-title-${work.id}`">{{ work.title }}</h2>
    <p class="work-card__description" :data-testid="`work-desc-${work.id}`">{{ work.description }}</p>
  </article>
</template>

<style scoped>
.work-card {
  padding: 1.25rem;
  border: 1px solid #d7dce3;
  border-radius: 12px;
  background: #ffffff;
  box-shadow: 0 2px 6px rgba(20, 30, 50, 0.06);
}

.work-card__title {
  margin: 0 0 0.5rem;
  font-size: 1.15rem;
  color: #1d2b3a;
}

.work-card__description {
  margin: 0;
  line-height: 1.6;
  color: #46535f;
}
</style>
