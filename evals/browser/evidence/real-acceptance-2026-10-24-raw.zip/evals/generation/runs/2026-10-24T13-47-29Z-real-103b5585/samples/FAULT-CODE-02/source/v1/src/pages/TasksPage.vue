<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import { createTask, loadTasks, saveTasks, type Task } from '../data/tasks';

const tasks = ref<Task[]>([]);
const newTitle = ref<string>('');

const remainingCount = computed<number>(() => tasks.value.filter((t) => !t.completed).length);

function persist(): void {
  saveTasks(tasks.value);
}

function addTask(): void {
  const title = newTitle.value.trim();
  if (!title) {
    return;
  }
  tasks.value.push(createTask(title));
  newTitle.value = '';
  persist();
}

function toggleTask(task: Task): void {
  task.completed = !task.completed;
  persist();
}

function removeTask(id: string): void {
  tasks.value = tasks.value.filter((t) => t.id !== id);
  persist();
}

onMounted(() => {
  tasks.value = loadTasks();
});
const d21EvalInjectedCount: number = 'D21 injected type fault';
</script>

<template>
  <main class="tasks-page">
    <h1 class="page-title" data-testid="page-title">个人待办清单</h1>

    <section class="add-form">
      <input
        v-model="newTitle"
        class="task-input"
        data-testid="task-input"
        type="text"
        placeholder="输入任务标题"
        @keyup.enter="addTask"
      />
      <button class="add-button" data-testid="add-button" type="button" @click="addTask">
        添加
      </button>
    </section>

    <p class="remaining" data-testid="remaining-count">未完成：{{ remainingCount }}</p>

    <p v-if="tasks.length === 0" class="empty" data-testid="empty-state">暂无任务</p>

    <ul class="task-list">
      <li v-for="task in tasks" :key="task.id" class="task-item" data-testid="task-item">
        <label class="task-label">
          <input
            type="checkbox"
            :checked="task.completed"
            :data-testid="`toggle-${task.id}`"
            @change="toggleTask(task)"
          />
          <span
            class="task-title"
            :class="{ completed: task.completed }"
            :data-testid="`title-${task.id}`"
          >
            {{ task.title }}
          </span>
        </label>
        <button
          class="delete-button"
          type="button"
          :data-testid="`delete-${task.id}`"
          @click="removeTask(task.id)"
        >
          删除
        </button>
      </li>
    </ul>
  </main>
</template>

<style scoped>
.tasks-page {
  max-width: 520px;
  margin: 0 auto;
  padding: 24px 16px;
  font-family: system-ui, sans-serif;
  color: #1f2937;
}

.page-title {
  font-size: 24px;
  margin-bottom: 20px;
}

.add-form {
  display: flex;
  gap: 8px;
}

.task-input {
  flex: 1;
  padding: 8px 10px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 14px;
}

.add-button {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  background: #2563eb;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
}

.remaining {
  margin: 16px 0;
  font-size: 14px;
  color: #4b5563;
}

.empty {
  font-size: 14px;
  color: #9ca3af;
}

.task-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.task-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #e5e7eb;
}

.task-label {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}

.task-title.completed {
  text-decoration: line-through;
  color: #9ca3af;
}

.delete-button {
  padding: 4px 10px;
  border: 1px solid #ef4444;
  border-radius: 6px;
  background: transparent;
  color: #ef4444;
  font-size: 13px;
  cursor: pointer;
}
</style>
