<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import type { Task } from '../data/tasks';
import { createTask, loadTasks, saveTasks } from '../data/tasks';

const tasks = ref<Task[]>([]);
const newTitle = ref('');
const loaded = ref(false);

const remaining = computed(() => tasks.value.filter((t) => !t.done).length);

onMounted(() => {
  tasks.value = loadTasks();
  loaded.value = true;
});

function persist(): void {
  saveTasks(tasks.value);
}

function addTask(): void {
  const title = newTitle.value.trim();
  if (!title) {
    return;
  }
  tasks.value.push(createTask(title));
  newTitle.value = '';
  persist();
}

function toggleTask(id: string): void {
  const task = tasks.value.find((t) => t.id === id);
  if (task) {
    task.done = !task.done;
    persist();
  }
}

function removeTask(id: string): void {
  tasks.value = tasks.value.filter((t) => t.id !== id);
  persist();
}
</script>

<template>
  <main class="tasks">
    <h1 class="tasks-title" data-testid="page-title">个人待办清单</h1>

    <section class="tasks-form">
      <input
        v-model="newTitle"
        class="tasks-input"
        data-testid="task-input"
        type="text"
        placeholder="输入任务标题"
        @keyup.enter="addTask"
      />
      <button class="tasks-add" data-testid="add-button" type="button" @click="addTask">
        添加
      </button>
    </section>

    <p class="tasks-count" data-testid="remaining-count">未完成：{{ remaining }}</p>

    <ul v-if="tasks.length > 0" class="tasks-list" data-testid="task-list">
      <li
        v-for="task in tasks"
        :key="task.id"
        class="tasks-item"
        :class="{ 'tasks-item--done': task.done }"
        :data-testid="'task-item-' + task.id"
      >
        <label class="tasks-item-label">
          <input
            class="tasks-checkbox"
            type="checkbox"
            :checked="task.done"
            :data-testid="'task-check-' + task.id"
            @change="toggleTask(task.id)"
          />
          <span class="tasks-item-title" :data-testid="'task-title-' + task.id">{{ task.title }}</span>
          <span class="tasks-item-status">{{ task.done ? '已完成' : '未完成' }}</span>
        </label>
        <button
          class="tasks-delete"
          type="button"
          :data-testid="'task-delete-' + task.id"
          @click="removeTask(task.id)"
        >
          删除
        </button>
      </li>
    </ul>
    <p v-else-if="loaded" class="tasks-empty" data-testid="empty-hint">暂无任务</p>
  </main>
</template>

<style scoped>
.tasks {
  max-width: 560px;
  margin: 0 auto;
  padding: 2rem 1rem;
  font-family: system-ui, sans-serif;
}

.tasks-title {
  font-size: 1.6rem;
  margin-bottom: 1rem;
}

.tasks-form {
  display: flex;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
}

.tasks-input {
  flex: 1;
  padding: 0.5rem 0.75rem;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 1rem;
}

.tasks-add {
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  background: #2563eb;
  color: #fff;
  font-size: 1rem;
  cursor: pointer;
}

.tasks-count {
  color: #475569;
  margin-bottom: 0.75rem;
}

.tasks-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.tasks-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.75rem;
  padding: 0.6rem 0.75rem;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  margin-bottom: 0.5rem;
}

.tasks-item-label {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex: 1;
  cursor: pointer;
}

.tasks-item-title {
  flex: 1;
}

.tasks-item--done .tasks-item-title {
  text-decoration: line-through;
  color: #94a3b8;
}

.tasks-item-status {
  font-size: 0.8rem;
  color: #64748b;
}

.tasks-delete {
  padding: 0.35rem 0.75rem;
  border: 1px solid #ef4444;
  border-radius: 6px;
  background: #fff;
  color: #ef4444;
  cursor: pointer;
}

.tasks-empty {
  color: #94a3b8;
}
</style>
