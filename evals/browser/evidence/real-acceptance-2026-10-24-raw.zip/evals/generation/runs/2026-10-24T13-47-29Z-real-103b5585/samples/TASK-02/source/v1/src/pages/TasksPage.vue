<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import type { ColumnId, Task } from '../data/taskStore';
import { COLUMNS, loadTasks, nextColumn, saveTasks } from '../data/taskStore';

const tasks = ref<Task[]>([]);
const newTitle = ref<string>('');
const loaded = ref<boolean>(false);

onMounted(() => {
  tasks.value = loadTasks();
  loaded.value = true;
});

function persist(): void {
  saveTasks(tasks.value);
}

function columnTasks(column: ColumnId): Task[] {
  return tasks.value.filter((task) => task.column === column);
}

const columnGroups = computed(() =>
  COLUMNS.map((column) => ({ column, items: columnTasks(column.id) }))
);

function addTask(): void {
  const title = newTitle.value.trim();
  if (!title) {
    return;
  }
  const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  tasks.value.push({ id, title, column: 'todo' });
  newTitle.value = '';
  persist();
}

function advance(task: Task): void {
  const target = nextColumn(task.column);
  if (!target) {
    return;
  }
  task.column = target;
  tasks.value = [...tasks.value];
  persist();
}

function removeTask(id: string): void {
  tasks.value = tasks.value.filter((task) => task.id !== id);
  persist();
}
</script>

<template>
  <main class="board-page">
    <h1 class="board-title">学习计划看板</h1>
    <form class="new-task" @submit.prevent="addTask">
      <input
        v-model="newTitle"
        class="task-input"
        data-testid="task-input"
        type="text"
        placeholder="输入任务标题"
      />
      <button class="btn-add" data-testid="add-task" type="submit">新建任务</button>
    </form>
    <div class="board">
      <section v-for="group in columnGroups" :key="group.column.id" class="column" :data-testid="`column-${group.column.id}`">
        <h2 class="column-title" :data-testid="`column-title-${group.column.id}`">{{ group.column.title }}</h2>
        <p v-if="group.items.length === 0" class="empty">暂无任务</p>
        <ul class="task-list">
          <li v-for="task in group.items" :key="task.id" class="task-card" :data-testid="`task-${task.id}`">
            <span class="task-title" :data-testid="`task-title-${task.id}`">{{ task.title }}</span>
            <div class="task-actions">
              <button
                v-if="task.column !== 'done'"
                class="btn-next"
                data-testid="next-task"
                type="button"
                @click="advance(task)"
              >下一步</button>
              <button
                class="btn-delete"
                data-testid="delete-task"
                type="button"
                @click="removeTask(task.id)"
              >删除</button>
            </div>
          </li>
        </ul>
      </section>
    </div>
  </main>
</template>

<style scoped>
.board-page {
  padding: 24px;
  font-family: system-ui, -apple-system, sans-serif;
  color: #1f2937;
  background: #f5f7fb;
  min-height: 100vh;
}

.board-title {
  margin: 0 0 16px;
  font-size: 24px;
}

.new-task {
  display: flex;
  gap: 8px;
  margin-bottom: 24px;
}

.task-input {
  flex: 1;
  max-width: 320px;
  padding: 8px 12px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 14px;
}

.btn-add {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  background: #2563eb;
  color: #fff;
  font-size: 14px;
  cursor: pointer;
}

.board {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
}

.column {
  background: #ffffff;
  border-radius: 10px;
  padding: 12px;
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.08);
}

.column-title {
  margin: 0 0 12px;
  font-size: 16px;
  color: #334155;
}

.empty {
  margin: 0;
  font-size: 13px;
  color: #94a3b8;
}

.task-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.task-card {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 10px;
}

.task-title {
  display: block;
  font-size: 14px;
  margin-bottom: 8px;
  word-break: break-word;
}

.task-actions {
  display: flex;
  gap: 8px;
}

.btn-next,
.btn-delete {
  padding: 4px 10px;
  font-size: 12px;
  border-radius: 5px;
  cursor: pointer;
}

.btn-next {
  border: 1px solid #2563eb;
  background: #fff;
  color: #2563eb;
}

.btn-delete {
  border: 1px solid #dc2626;
  background: #fff;
  color: #dc2626;
}
</style>
