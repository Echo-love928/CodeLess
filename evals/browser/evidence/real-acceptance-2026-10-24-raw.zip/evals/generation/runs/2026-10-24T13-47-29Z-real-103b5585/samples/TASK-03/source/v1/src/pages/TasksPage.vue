<script setup lang="ts">
import { ref, watch } from 'vue';
import type { ShoppingItem } from '../data/shoppingList';
import { createItem, loadItems, saveItems } from '../data/shoppingList';

const items = ref<ShoppingItem[]>(loadItems());
const nameInput = ref<string>('');
const quantityInput = ref<number>(1);

watch(
  items,
  (value: ShoppingItem[]) => {
    saveItems(value);
  },
  { deep: true },
);

function addItem(): void {
  const name = nameInput.value.trim();
  const quantity = Math.floor(Number(quantityInput.value));
  if (!name || !Number.isFinite(quantity) || quantity < 1) {
    return;
  }
  items.value.push(createItem(name, quantity));
  nameInput.value = '';
  quantityInput.value = 1;
}

function togglePurchased(id: string): void {
  const target = items.value.find((item: ShoppingItem) => item.id === id);
  if (target) {
    target.purchased = !target.purchased;
  }
}

function removeItem(id: string): void {
  items.value = items.value.filter((item: ShoppingItem) => item.id !== id);
}

function clearPurchased(): void {
  items.value = items.value.filter((item: ShoppingItem) => !item.purchased);
}
</script>

<template>
  <main class="shopping-page">
    <h1 class="page-title" data-testid="page-title">家庭购物清单</h1>

    <form class="entry-form" @submit.prevent="addItem">
      <label class="field">
        <span>商品名称</span>
        <input
          v-model="nameInput"
          type="text"
          placeholder="例如：牛奶"
          data-testid="name-input"
        />
      </label>
      <label class="field">
        <span>数量</span>
        <input
          v-model="quantityInput"
          type="number"
          min="1"
          data-testid="quantity-input"
        />
      </label>
      <button type="submit" class="primary" data-testid="add-button">加入清单</button>
    </form>

    <div class="toolbar">
      <span class="summary" data-testid="summary">共 {{ items.length }} 项，已购买 {{ items.filter((item: ShoppingItem) => item.purchased).length }} 项</span>
      <button type="button" class="secondary" data-testid="clear-purchased" @click="clearPurchased">清除已购买</button>
    </div>

    <p v-if="items.length === 0" class="empty" data-testid="empty-state">清单为空，请添加商品。</p>

    <ul v-else class="item-list">
      <li
        v-for="item in items"
        :key="item.id"
        class="item"
        :class="{ purchased: item.purchased }"
        :data-testid="`item-${item.id}`"
      >
        <div class="item-info">
          <span class="item-name" :data-testid="`item-name-${item.id}`">{{ item.name }}</span>
          <span class="item-quantity" :data-testid="`item-quantity-${item.id}`">数量：{{ item.quantity }}</span>
          <span class="item-status" :data-testid="`item-status-${item.id}`">{{ item.purchased ? '已购买' : '未购买' }}</span>
        </div>
        <div class="item-actions">
          <button
            type="button"
            class="secondary"
            :data-testid="`toggle-${item.id}`"
            @click="togglePurchased(item.id)"
          >
            {{ item.purchased ? '取消已购买' : '标记已购买' }}
          </button>
          <button
            type="button"
            class="danger"
            :data-testid="`delete-${item.id}`"
            @click="removeItem(item.id)"
          >
            删除
          </button>
        </div>
      </li>
    </ul>
  </main>
</template>

<style scoped>
.shopping-page {
  max-width: 720px;
  margin: 0 auto;
  padding: 24px 16px 48px;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  color: #1f2937;
}
.page-title {
  font-size: 1.6rem;
  margin-bottom: 20px;
}
.entry-form {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: flex-end;
  margin-bottom: 16px;
}
.field {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 0.9rem;
}
.field input {
  padding: 8px 10px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 1rem;
}
button {
  padding: 8px 14px;
  border: none;
  border-radius: 6px;
  font-size: 0.95rem;
  cursor: pointer;
}
.primary {
  background: #2563eb;
  color: #fff;
}
.secondary {
  background: #e2e8f0;
  color: #1f2937;
}
.danger {
  background: #dc2626;
  color: #fff;
}
.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  gap: 12px;
  flex-wrap: wrap;
}
.summary {
  font-size: 0.9rem;
  color: #475569;
}
.empty {
  color: #64748b;
}
.item-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  padding: 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #fff;
}
.item.purchased .item-name {
  text-decoration: line-through;
  color: #94a3b8;
}
.item-info {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  align-items: center;
}
.item-name {
  font-weight: 600;
}
.item-quantity,
.item-status {
  font-size: 0.9rem;
  color: #475569;
}
.item-actions {
  display: flex;
  gap: 8px;
}
</style>
