export type ColumnId = 'todo' | 'doing' | 'done';

export interface Task {
  id: string;
  title: string;
  column: ColumnId;
}

export interface ColumnDef {
  id: ColumnId;
  title: string;
}

export const COLUMNS: ColumnDef[] = [
  { id: 'todo', title: '待开始' },
  { id: 'doing', title: '进行中' },
  { id: 'done', title: '已完成' }
];

const STORAGE_KEY = 'study-plan-board-tasks';

function isColumnId(value: unknown): value is ColumnId {
  return value === 'todo' || value === 'doing' || value === 'done';
}

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }
    const tasks: Task[] = [];
    for (const item of parsed) {
      if (typeof item !== 'object' || item === null) {
        continue;
      }
      const record = item as Record<string, unknown>;
      const id = record.id;
      const title = record.title;
      const column = record.column;
      if (typeof id === 'string' && typeof title === 'string' && isColumnId(column)) {
        tasks.push({ id, title, column });
      }
    }
    return tasks;
  } catch {
    return [];
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch {
    // ignore storage failures
  }
}

export function nextColumn(column: ColumnId): ColumnId | null {
  if (column === 'todo') {
    return 'doing';
  }
  if (column === 'doing') {
    return 'done';
  }
  return null;
}
