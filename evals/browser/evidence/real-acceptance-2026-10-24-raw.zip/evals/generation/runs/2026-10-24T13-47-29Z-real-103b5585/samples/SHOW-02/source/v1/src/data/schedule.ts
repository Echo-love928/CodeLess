export interface ScheduleItem {
  time: string;
  title: string;
}

export const scheduleItems: ScheduleItem[] = [
  { time: '09:00', title: '开幕致辞' },
  { time: '10:30', title: 'Vue 性能优化实战' },
  { time: '14:00', title: '无障碍设计实践' }
];
