export interface Task {
  id: string;
  title: string;
  done: boolean;
}

export const STORAGE_KEY = 'todo-tasks';

export const defaultTasks: Task[] = [];

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return defaultTasks.map((t) => ({ ...t }));
    }
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return defaultTasks.map((t) => ({ ...t }));
    }
    const result: Task[] = [];
    for (const item of parsed) {
      if (
        item !== null &&
        typeof item === 'object' &&
        typeof (item as Record<string, unknown>).id === 'string' &&
        typeof (item as Record<string, unknown>).title === 'string' &&
        typeof (item as Record<string, unknown>).done === 'boolean'
      ) {
        const rec = item as Record<string, unknown>;
        result.push({
          id: rec.id as string,
          title: rec.title as string,
          done: rec.done as boolean,
        });
      }
    }
    return result;
  } catch {
    return defaultTasks.map((t) => ({ ...t }));
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  } catch {
    // ignore storage errors
  }
}

export function createTask(title: string): Task {
  return {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
    title,
    done: false,
  };
}
