export interface Work {
  id: string;
  title: string;
  description: string;
}

export const works: Work[] = [
  {
    id: 'mark-i',
    title: 'Harvard Mark I 编程',
    description: '为早期大型计算机编写程序，推动了机器指令与编程方法的实践。',
  },
  {
    id: 'a-0',
    title: 'A-0 编译器',
    description: '开发早期编译器，让程序可以用更接近人类语言的符号来编写。',
  },
  {
    id: 'cobol',
    title: 'COBOL 标准化',
    description: '推动 COBOL 成为通用商业编程语言，并参与其标准化工作。',
  },
];

export const contactEmail = 'grace.hopper@example.com';
