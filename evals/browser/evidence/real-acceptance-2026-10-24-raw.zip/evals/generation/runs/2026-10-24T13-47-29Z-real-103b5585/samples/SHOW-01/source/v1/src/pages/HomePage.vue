<script setup lang="ts">
import WorkCard from '../components/WorkCard.vue';
import { profile, works } from '../data/works.ts';
import type { Work } from '../data/works.ts';

const workList: Work[] = works;
</script>

<template>
  <div class="home-page">
    <header class="hero">
      <h1 class="hero__name" data-testid="profile-name">{{ profile.name }}</h1>
      <p class="hero__tagline" data-testid="profile-tagline">{{ profile.tagline }}</p>
    </header>

    <main class="works" data-testid="works-list">
      <WorkCard v-for="work in workList" :key="work.id" :work="work" />
    </main>

    <footer class="contact">
      <span class="contact__email" data-testid="contact-email">{{ profile.email }}</span>
    </footer>
  </div>
</template>

<style scoped>
.home-page {
  max-width: 960px;
  margin: 0 auto;
  padding: 2.5rem 1.25rem 3rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
}

.hero {
  text-align: center;
}

.hero__name {
  margin: 0 0 0.75rem;
  font-size: 2.25rem;
  color: #16263a;
}

.hero__tagline {
  margin: 0;
  font-size: 1.05rem;
  color: #4a5866;
}

.works {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.25rem;
}

.contact {
  text-align: center;
  padding-top: 1rem;
  border-top: 1px solid #e2e6eb;
}

.contact__email {
  font-size: 0.95rem;
  color: #46535f;
}
</style>
