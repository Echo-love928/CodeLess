<script setup lang="ts">
import { ref } from 'vue';
import ScheduleList from '../components/ScheduleList.vue';
import { eventInfo } from '../data/eventData';

const registered = ref(false);

function handleRegister(): void {
  registered.value = true;
}
</script>

<template>
  <main class="home">
    <h1 class="event-name" data-testid="event-name">{{ eventInfo.name }}</h1>
    <p class="event-date" data-testid="event-date">{{ eventInfo.date }}</p>
    <p class="event-location" data-testid="event-location">{{ eventInfo.location }}</p>

    <h2 class="schedule-heading">活动日程</h2>
    <ScheduleList :items="eventInfo.schedule" />

    <div class="actions">
      <button type="button" class="register-btn" data-testid="register-btn" @click="handleRegister">
        我要报名
      </button>
      <p v-if="registered" class="register-note" data-testid="register-note">
        报名意向已记录（演示）
      </p>
    </div>
  </main>
</template>

<style scoped>
.home {
  max-width: 720px;
  margin: 0 auto;
  padding: 32px 20px;
  font-family: system-ui, -apple-system, sans-serif;
  color: #1f2937;
}

.event-name {
  margin: 0 0 12px;
  font-size: 28px;
}

.event-date,
.event-location {
  margin: 4px 0;
  color: #4b5563;
}

.schedule-heading {
  margin: 28px 0 8px;
  font-size: 20px;
}

.actions {
  margin-top: 24px;
}

.register-btn {
  padding: 10px 24px;
  font-size: 16px;
  color: #ffffff;
  background-color: #2563eb;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.register-note {
  margin-top: 12px;
  color: #16a34a;
}
</style>
