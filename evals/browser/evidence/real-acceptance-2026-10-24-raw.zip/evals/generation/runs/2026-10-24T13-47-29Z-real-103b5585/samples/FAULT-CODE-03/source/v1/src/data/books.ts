export type BookCategory = '小说' | '科技' | '历史';

export interface Book {
  id: number;
  title: string;
  author: string;
  category: BookCategory;
  summary: string;
}

export const books: Book[] = [
  {
    id: 1,
    title: '平凡的世界',
    author: '路遥',
    category: '小说',
    summary: '以孙少安、孙少平兄弟为中心，描绘中国城乡社会的变迁与普通人的奋斗。'
  },
  {
    id: 2,
    title: '三体',
    author: '刘慈欣',
    category: '小说',
    summary: '地球文明与三体文明的首次接触，展开一场跨越星际的生存博弈。'
  },
  {
    id: 3,
    title: '活着',
    author: '余华',
    category: '小说',
    summary: '讲述农民福贵历经家国动荡，在苦难中坚韧活下去的一生。'
  },
  {
    id: 4,
    title: '时间简史',
    author: '史蒂芬·霍金',
    category: '科技',
    summary: '从大爆炸到黑洞，用通俗语言讲述宇宙的起源与命运。'
  },
  {
    id: 5,
    title: '代码大全',
    author: '史蒂夫·迈克康奈尔',
    category: '科技',
    summary: '软件构建领域的经典之作，系统讲解编写高质量代码的实践方法。'
  },
  {
    id: 6,
    title: '人工智能：一种现代的方法',
    author: '斯图尔特·罗素',
    category: '科技',
    summary: '全面介绍人工智能的基本概念、算法与应用的权威教材。'
  },
  {
    id: 7,
    title: '万历十五年',
    author: '黄仁宇',
    category: '历史',
    summary: '以万历十五年为切入点，剖析明代政治与社会结构的深层问题。'
  },
  {
    id: 8,
    title: '人类简史',
    author: '尤瓦尔·赫拉利',
    category: '历史',
    summary: '从认知革命到科学革命，重新审视智人如何塑造今日世界。'
  }
];
