<script setup lang="ts">
import type { Work } from '../data/works';

defineProps<{ work: Work }>();
</script>

<template>
  <article class="work-card" :data-testid="'work-' + work.id">
    <h2 class="work-card__title">{{ work.title }}</h2>
    <p class="work-card__description">{{ work.description }}</p>
  </article>
</template>

<style scoped>
.work-card {
  padding: 1.25rem;
  border: 1px solid #d7dce2;
  border-radius: 10px;
  background-color: #ffffff;
}

.work-card__title {
  margin: 0 0 0.5rem;
  font-size: 1.1rem;
  color: #1f2933;
}

.work-card__description {
  margin: 0;
  line-height: 1.6;
  color: #4a5568;
}
</style>
