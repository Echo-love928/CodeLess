<script setup lang="ts">
import type { ScheduleItem } from '../data/schedule';

defineProps<{ items: ScheduleItem[] }>();
</script>

<template>
  <ul class="schedule-list">
    <li v-for="(item, index) in items" :key="index" class="schedule-item" :data-testid="`schedule-item-${index}`">
      <span class="schedule-time">{{ item.time }}</span>
      <span class="schedule-title">{{ item.title }}</span>
    </li>
  </ul>
</template>

<style scoped>
.schedule-list {
  list-style: none;
  margin: 0;
  padding: 0;
}

.schedule-item {
  display: flex;
  gap: 1rem;
  padding: 0.75rem 0;
  border-bottom: 1px solid #e5e7eb;
}

.schedule-time {
  font-weight: 600;
  min-width: 4rem;
}
</style>
