# D21-A 生成评测报告 2026-10-24T13-47-29Z-real-103b5585

由 `scripts/eval/report.mjs#v2` 从本目录原始记录生成；`node scripts/eval/report.mjs <batchDir> --check` 可复算。

- 模式：**REAL**（REAL_MODEL）；真实模型证据：是
- Provider：deepseek / deepseek-flash；其他 provider 调用：0
- 平台提交：`0d831a7730c7df542961553a2e68e41bf84b858e`（IN_PLACE）
- 冻结集：requirements sha256:ef219f3e5c0f05f3ab03ec854c66b32709349f80d1e1aee0076fe19d2b91cb2a，faults sha256:4b147818de5823b2ba3011cc65f57a08f63270154aa01289af8e7631c8790b13，run-config sha256:6dc271c657cdb29e72ec052621fc2633ac5d82b8d8d963bfbffccd0d929cb054
- 完成度：计划 14，已启动 14，原始记录 14，批次完成 是，凭据出现次数 0

## 9 个需求（分母固定为冻结计划）

- 首轮成功（首次真实构建+浏览器即通过、0 次修复）：**2/9**（22.2%）
- 3 轮内最终成功（平台 READY）：**2/9**（22.2%）；目标 ≥8/9：未达到（基线目标，不是既有成绩）
- 需求级最终成功（叠加 D21-B 行为断言）：PENDING_D21_B，当前为未知，不计为成功
- 缺失记录：无；harness 错误：无；样本进程异常（不计成功）：无
- 修复：共 1 轮，1 个样本发生修复
- 实际 token：222315；输入 200373 / 输出 21942；已知下限 输入 200373 / 输出 21942；缓存命中（已含在输入中）151040
- 运行时预算计费（含保守估算，非实际用量）：222315，估算调用 0
- 模型请求 61，工具槽 60；耗时中位数 40.5 s，最大 64.6 s（已知 9，未知 0）
- 失败类型：MODEL_OUTPUT×2，BUDGET×3，ENVIRONMENT×2

| 需求 | 类别 | 任务 ID | 首次验证 | 最终 | 修复轮 | 失败类型 / 代码 | 模型请求 | 实际 token | 耗时 |
| --- | --- | --- | --- | --- | ---: | --- | ---: | --- | ---: |
| SHOW-01 | SHOWCASE | a5e3ec52-c4a9-43ec-bc57-5372e9ff7eaa | FAILED | FAILED | 1 | BUDGET / AGENT_MODEL_BUDGET_EXCEEDED | 11 | 38255 | 64.6 s |
| SHOW-02 | SHOWCASE | 199f2723-c614-48c5-962d-932b347bcce3 | VERIFIED | READY | 0 | — | 8 | 27791 | 47.7 s |
| SHOW-03 | SHOWCASE | dab36bbc-2157-4e36-818d-39d52eebedad | NONE | FAILED | 0 | BUDGET / AGENT_MODEL_BUDGET_EXCEEDED | 8 | 30040 | 30.0 s |
| TASK-01 | TASKS | 48f1f725-ed69-46ce-9067-9e9084f12b8b | FAILED | FAILED | 0 | ENVIRONMENT / AGENT_ACTION_TIMEOUT | 6 | 21687 | 40.5 s |
| TASK-02 | TASKS | 32eaceff-45b9-43ac-85df-f03f500b867e | VERIFIED | READY | 0 | — | 6 | 22553 | 42.9 s |
| TASK-03 | TASKS | 9bb3c095-cd53-47e9-a015-0e95cef8dcb9 | FAILED | FAILED | 0 | ENVIRONMENT / AGENT_ACTION_TIMEOUT | 6 | 22178 | 45.8 s |
| CAT-01 | CATALOG | a9978317-e1a7-4ed4-b3dc-952cff45ba60 | NONE | FAILED | 0 | MODEL_OUTPUT / AGENT_ACCEPTANCE_INVALID | 6 | 23053 | 24.2 s |
| CAT-02 | CATALOG | 489afbd0-a516-490c-a753-77868f82883e | NONE | FAILED | 0 | BUDGET / AGENT_MODEL_BUDGET_EXCEEDED | 8 | 31860 | 32.5 s |
| CAT-03 | CATALOG | ace53db6-2923-4e05-a312-41b8483a3da0 | NONE | FAILED | 0 | MODEL_OUTPUT / MODEL_INVALID_RESPONSE | 2 | 4898 | 7.1 s |

## 故障集（与 9 个需求分开统计）

- 代码故障按预期修复：**0/3**；环境故障按预期停止：**2/2**
- 故障集实际 token：≥133964（1 次未知）

### FAULT-CODE-01（CODE / MISSING_MODULE_IMPORT，基于 SHOW-01）：FAILED

任务 fd38c6f1-0355-4794-ab74-80bc218a960f；最终 FAILED；修复轮 2；失败 BUDGET / AGENT_MODEL_BUDGET_EXCEEDED

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "CODE" | 通过 |
| first decision | "REPAIR" | "REPAIR" | 通过 |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 2 | 通过 |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | true | 通过 |

### FAULT-CODE-02（CODE / STRICT_TYPE_ERROR，基于 TASK-01）：FAILED

任务 7fac2203-e2f8-4398-be8a-d33a66f2ec99；最终 FAILED；修复轮 1；失败 MODEL_OUTPUT / AGENT_MODEL_PROTOCOL_INVALID

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "CODE" | 通过 |
| first decision | "REPAIR" | "REPAIR" | 通过 |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 1 | 通过 |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | false | **未通过** |

### FAULT-CODE-03（CODE / RUNTIME_ASYNC_PAGE_EXCEPTION，基于 CAT-01）：FAILED

任务 4ed629e9-60a2-4d8a-b06e-47f24f56550c；最终 FAILED；修复轮 1；失败 BUDGET / AGENT_MODEL_BUDGET_EXCEEDED

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| injection applied | "APPLIED" | "APPLIED" | 通过 |
| injection labelled | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | "HOST_TEST_INJECTION_NOT_SPONTANEOUS_MODEL_ERROR" | 通过 |
| first verify | "FAILED" | "FAILED" | 通过 |
| first failure category | "CODE" | "CODE" | 通过 |
| first decision | "REPAIR" | "REPAIR" | 通过 |
| final | "READY" | "FAILED" | **未通过** |
| repair rounds | "1..3" | 1 | 通过 |
| acceptance actions unchanged | true | true | 通过 |
| final source differs from injected source | true | false | **未通过** |

### FAULT-ENV-01（ENVIRONMENT / CONTAINER_CLI_UNAVAILABLE，基于 SHOW-02）：PASSED

任务 cc878e2e-d6d9-4809-9248-a10cee06990f；最终 FAILED；修复轮 0；失败 ENVIRONMENT / AGENT_RUNNER_UNAVAILABLE

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| container CLI absent in sample JVM | false | false | 通过 |
| final | "FAILED" | "FAILED" | 通过 |
| failure stage | "VERIFY" | "VERIFY" | 通过 |
| failure category | "INFRASTRUCTURE" | "INFRASTRUCTURE" | 通过 |
| no REPAIR decision | true | true | 通过 |
| repair rounds | 0 | 0 | 通过 |
| REPAIR model calls | 0 | 0 | 通过 |
| immutable candidates | 1 | 1 | 通过 |
| file tool calls after failure | 0 | 0 | 通过 |

### FAULT-ENV-02（ENVIRONMENT / MODEL_ENDPOINT_UNREACHABLE，基于 TASK-02）：PASSED

任务 3330f09f-f407-4e8d-aa13-e5f33674bc55；最终 FAILED；修复轮 0；失败 MODEL_TRANSPORT / MODEL_NETWORK

| 检查 | 期望 | 实际 | 结果 |
| --- | --- | --- | --- |
| sample JVM exit | "OK" | "OK" | 通过 |
| harness error | null | null | 通过 |
| journal and model calls recorded | true | true | 通过 |
| proxy route refused before task | "REFUSED" | "REFUSED" | 通过 |
| final | "FAILED" | "FAILED" | 通过 |
| failure code | "MODEL_NETWORK" | "MODEL_NETWORK" | 通过 |
| failure category | "MODEL_INTERFACE" | "MODEL_INTERFACE" | 通过 |
| model calls (no retry) | 1 | 1 | 通过 |
| failed call usage | "UNKNOWN" | "UNKNOWN" | 通过 |
| file tool calls | 0 | 0 | 通过 |
| repair rounds | 0 | 0 | 通过 |

## 一致性核对

评测计算的模型请求数、工具槽与预算计费均与平台日志计量一致。


## 输入文件摘要

- `batch-complete.json` sha256:494900a1857e75795f310fb4eba42fa2286112d3bea8d1c728a65b4b6b3e3fd0
- `batch.json` sha256:091582918da2ff11784eecdae08f836ff3112c25c88e55a4e0754882c8524af5
- `frozen/faults.json` sha256:4b147818de5823b2ba3011cc65f57a08f63270154aa01289af8e7631c8790b13
- `frozen/requirements.json` sha256:ef219f3e5c0f05f3ab03ec854c66b32709349f80d1e1aee0076fe19d2b91cb2a
- `frozen/runConfig.json` sha256:6dc271c657cdb29e72ec052621fc2633ac5d82b8d8d963bfbffccd0d929cb054
- `samples/CAT-01/invocation-result.json` sha256:771c134902fffb8396be8cdb1fcce0b4b8158a881c5acd152d00d7e06656a967
- `samples/CAT-01/record.json` sha256:6012ee23fa02e617e62baf860756ac9867ec9c6a5fb7b47a604209ff6df3116e
- `samples/CAT-01/spec.json` sha256:1cae9acb16cfaac476b8b01d8485d94c81151ed5c9cd7d0aa01488782d94bd94
- `samples/CAT-02/invocation-result.json` sha256:ae7732f358086fb1602dcd6019d73810bde873840ccb62ca293814f17c9685c3
- `samples/CAT-02/record.json` sha256:59e74a00b5481e821b1e7725d4745261aaaa7e14d86297cee974ddbc4ea9f044
- `samples/CAT-02/spec.json` sha256:17f59bc579962e36f42fe433a21e0a2a1a3c56ac45e9586df02112be2cb70408
- `samples/CAT-03/invocation-result.json` sha256:a83fc94b3294e8bc75895fe494c863ae3677277a380609707616f3d298cf64c9
- `samples/CAT-03/record.json` sha256:c8ae842d0fe66981a72f99763fd8dff3ce49b6b37a39f312ec5cdfd70811e46f
- `samples/CAT-03/spec.json` sha256:f996c8375c5429ece39938b66d581b7d062b0efb8f98abb60303833e3eb21660
- `samples/FAULT-CODE-01/invocation-result.json` sha256:c9c80daad1fe486d32a632f6bbd525dc1613b36fd6c9360cdfb6c601c64c7a8e
- `samples/FAULT-CODE-01/record.json` sha256:ea0dd12f00300eaba0b0074d06efb78ca6ad589fed80f16710c5cfc2491a81b0
- `samples/FAULT-CODE-01/spec.json` sha256:17675a871a3a746aa825af990477cdeb25fa09c71c6a7ac57e9b13549ee958ef
- `samples/FAULT-CODE-02/invocation-result.json` sha256:9bd72faae60d1c0626e2c9e6920af93c633d7d08ffe55af224a40fbbef602150
- `samples/FAULT-CODE-02/record.json` sha256:d8b561141d14564830ffd5711571544874b3b119cd39cbb0deeac57dff08af21
- `samples/FAULT-CODE-02/spec.json` sha256:e26a2fb2782741425c493f3ec5fa18fe15eacbd3b9a2ceea8836f74f71b60d73
- `samples/FAULT-CODE-03/invocation-result.json` sha256:bd5e8258e09b65dddbd8675d07e593835c42de74fd1db01c63233a10dbfefc39
- `samples/FAULT-CODE-03/record.json` sha256:c170e130330e2aa251b36f88371cfae526433da5ef8af0ed8728043de14e0019
- `samples/FAULT-CODE-03/spec.json` sha256:164b04e0655d914b5ed07a439f5bfd7d4bbbabdf210dc1ddc6d45b5d65cb5453
- `samples/FAULT-ENV-01/invocation-result.json` sha256:9820eb05d31a54aff063c6dda450dc24bffcea25912ee7e00b8d22c1ed1be094
- `samples/FAULT-ENV-01/record.json` sha256:a4b66506a6602abcddad52583d81eb422c663e941da4cf2d8645947f6a6da493
- `samples/FAULT-ENV-01/spec.json` sha256:a8baf93add5d81f1fc73ce411a32729fa156f0dedc868d4e0043c6bd92f829f0
- `samples/FAULT-ENV-02/invocation-result.json` sha256:b7d7387807d1fcbec4e1c804034f1b7b184881f561bf8635bf19215cf00e764f
- `samples/FAULT-ENV-02/record.json` sha256:84199b2dbab50d6add2fa23e71c1caa92309851e7908509b13b494e8cfe5f6a8
- `samples/FAULT-ENV-02/spec.json` sha256:9e61196b457df9c69374db7aaed7d5048a67a21f92521a4fcbb69c9fb8930169
- `samples/SHOW-01/invocation-result.json` sha256:1c7b4ecc44c3d9a96b4f88ed241325fce228ace545a6979aa3ac1eb4df4d56ce
- `samples/SHOW-01/record.json` sha256:a53ae5b968be2edba786d427ecc76dd1687fd610caab12145b32f542b0352b77
- `samples/SHOW-01/spec.json` sha256:1d5da5cb2fa746f21a151c8a9e32cd3695a82ebecfde6cb7c85b1b5dae066141
- `samples/SHOW-02/invocation-result.json` sha256:b4263d33a7850da3a9022559f7c12b8ba6a704544bc70184ca4c9723e0c059ca
- `samples/SHOW-02/record.json` sha256:85c8a8426f9fb06cc68683dec8adc26f9e67143bcea2ed3b8c7fc0730d051a96
- `samples/SHOW-02/spec.json` sha256:dc25e7b1d2e7c2c75a16aae0c7d5cd6be980709ba87c16749f3e4d200a697b27
- `samples/SHOW-03/invocation-result.json` sha256:ef4fdafd497259ff3977de1001748cc842491ade6d214ac84d7b7283751ba0ab
- `samples/SHOW-03/record.json` sha256:9c2bc145a5b50477f95206ce3b3f072f735cf30d215942b03998a3cf1cd9c709
- `samples/SHOW-03/spec.json` sha256:aa4e5cacbf9ca9529b8224062a7ece722132283f98e502621e07caeb9cc7b931
- `samples/TASK-01/invocation-result.json` sha256:579f6f0e52bcc8ae7b630fe9b0e70b0064065e3f7d6d570409e6443f08c25a83
- `samples/TASK-01/record.json` sha256:f8e0ed1d8e9a7d651beba64689f4b62972b5a19069582986762dbdd66ae6b9b2
- `samples/TASK-01/spec.json` sha256:9a95bceeab261a411c3911a56b7b5bebc8d75ec035e091b3ed2de1b055667cee
- `samples/TASK-02/invocation-result.json` sha256:18d5745a3e9c50b5065a7516a448d01287875994133bfbd7a1d1c45d0cfb9c94
- `samples/TASK-02/record.json` sha256:ae7c72a0e02f24c9e2a59ba9763a8193ca6fae486be6b35f17132c29f558d6bf
- `samples/TASK-02/spec.json` sha256:82d3a47362dd6d909b1921948c5faac4722e9a9229f2527ff0b83b837801ee2f
- `samples/TASK-03/invocation-result.json` sha256:0c72460df252cfa44e6947b2f1302d4cc8123780b3da3d34368258d1944e4e29
- `samples/TASK-03/record.json` sha256:933a2dff16917e398fcc14d97e1c41653b65cb566a42a4144006b39e10b05b9d
- `samples/TASK-03/spec.json` sha256:ed7d5f226786ad27ce08ec1359fb0eec29bc2901e13333aa0ad63d0f1401230e
