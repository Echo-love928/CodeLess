export interface Work {
  id: string;
  title: string;
  description: string;
}

export interface Profile {
  name: string;
  tagline: string;
  email: string;
}

export const profile: Profile = {
  name: 'Grace Hopper',
  tagline: '计算机科学先驱，COBOL 语言的推动者',
  email: 'grace.hopper@example.com',
};

export const works: Work[] = [
  {
    id: 'mark-i',
    title: 'Harvard Mark I 编程',
    description: '为 Harvard Mark I 早期计算机编写程序，奠定实际计算编程的基础。',
  },
  {
    id: 'a-0',
    title: 'A-0 编译器',
    description: '开发 A-0 编译器，开创让计算机自动翻译程序代码的先河。',
  },
  {
    id: 'cobol',
    title: 'COBOL 标准化',
    description: '推动 COBOL 语言的标准化，使商业数据处理更加通用易读。',
  },
];
