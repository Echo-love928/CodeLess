<script setup lang="ts">
import D21EvalMissingPanel from '../components/D21EvalMissingPanel.vue';
import WorkCard from '../components/WorkCard.vue';
import { works, contactEmail } from '../data/works';
</script>

<template>
  <div class="home-page">
    <header class="home-page__header">
      <h1 class="home-page__name" data-testid="profile-name">Grace Hopper</h1>
      <p class="home-page__tagline" data-testid="profile-tagline">计算机科学先驱，COBOL 语言的推动者</p>
    </header>

    <section class="home-page__works" aria-label="代表作品">
      <WorkCard v-for="work in works" :key="work.id" :work="work" />
    </section>

    <footer class="home-page__footer">
      <p class="home-page__contact" data-testid="contact-email">{{ contactEmail }}</p>
    </footer>
  </div>
</template>

<style scoped>
.home-page {
  max-width: 960px;
  margin: 0 auto;
  padding: 2.5rem 1.25rem;
}

.home-page__header {
  text-align: center;
  margin-bottom: 2rem;
}

.home-page__name {
  margin: 0 0 0.5rem;
  font-size: 2rem;
  color: #1f2933;
}

.home-page__tagline {
  margin: 0;
  color: #4a5568;
}

.home-page__works {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 1.25rem;
}

.home-page__footer {
  margin-top: 2.5rem;
  text-align: center;
}

.home-page__contact {
  margin: 0;
  color: #4a5568;
}
</style>
