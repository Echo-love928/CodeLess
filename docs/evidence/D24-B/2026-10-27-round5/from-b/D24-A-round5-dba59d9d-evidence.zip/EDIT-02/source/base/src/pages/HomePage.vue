<script setup lang="ts">
import WorkCard from '../components/WorkCard.vue';
import { profile } from '../data/profile';
</script>

<template>
  <main class="home" data-ai-component="home-page">
    <header class="home__header">
      <h1 class="home__name">Grace Hopper · 计算机先驱</h1>
      <p class="home__tagline">{{ profile.tagline }}</p>
    </header>

    <section class="home__works">
      <h2 class="home__section-title">代表作品</h2>
      <div class="home__grid">
        <WorkCard
          v-for="work in profile.works"
          :key="work.id"
          :title="work.title"
          :description="work.description"
        />
      </div>
    </section>

    <footer class="home__footer">
      <h2 class="home__section-title">联系方式</h2>
      <p class="home__email">{{ profile.email }}</p>
    </footer>
  </main>
</template>

<style scoped>
.home {
  max-width: 960px;
  margin: 0 auto;
  padding: 32px 20px 48px;
  font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
  color: #1f2937;
}
.home__header {
  text-align: center;
  padding-bottom: 24px;
  border-bottom: 1px solid #e5e7eb;
}
.home__name {
  margin: 0 0 8px;
  font-size: 32px;
}
.home__tagline {
  margin: 0;
  font-size: 16px;
  color: #4b5563;
}
.home__works {
  padding: 24px 0;
}
.home__section-title {
  font-size: 18px;
  margin: 0 0 16px;
}
.home__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 16px;
}
.home__footer {
  padding-top: 16px;
  border-top: 1px solid #e5e7eb;
}
.home__email {
  margin: 0;
  font-size: 15px;
  color: #374151;
}
</style>
