<script setup lang="ts">
interface Props {
  title: string;
  description: string;
}

defineProps<Props>();
</script>

<template>
  <article class="work-card" data-ai-component="work-card" data-testid="work-card">
    <h3 class="work-card__title">{{ title }}</h3>
    <p class="work-card__desc">{{ description }}</p>
  </article>
</template>

<style scoped>
.work-card {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 16px;
  background: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
}
.work-card__title {
  margin: 0 0 8px;
  font-size: 16px;
  color: #1d4ed8;
}
.work-card__desc {
  margin: 0;
  font-size: 14px;
  color: #1d4ed8;
  line-height: 1.6;
}
</style>
