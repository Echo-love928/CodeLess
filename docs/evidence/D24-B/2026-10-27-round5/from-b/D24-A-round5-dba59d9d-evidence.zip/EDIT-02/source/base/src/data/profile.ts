export interface WorkItem {
  id: string;
  title: string;
  description: string;
}

export interface Profile {
  name: string;
  tagline: string;
  works: WorkItem[];
  email: string;
}

export const profile: Profile = {
  name: 'Grace Hopper',
  tagline: '计算机科学先驱，COBOL 语言的推动者',
  works: [
    {
      id: 'mark-i',
      title: 'Harvard Mark I 编程',
      description: '为 Harvard Mark I 早期计算机编写程序，奠定了机器编程的实践基础。',
    },
    {
      id: 'a-0',
      title: 'A-0 编译器',
      description: '设计了最早的编译器之一 A-0，让程序可以用更接近人类语言的方式表达。',
    },
    {
      id: 'cobol',
      title: 'COBOL 标准化',
      description: '推动了 COBOL 语言的标准化，使业务数据处理拥有通用且可移植的编程语言。',
    },
  ],
  email: 'grace.hopper@example.com',
};
