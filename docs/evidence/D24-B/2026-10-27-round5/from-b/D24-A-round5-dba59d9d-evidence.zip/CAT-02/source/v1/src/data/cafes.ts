export interface Cafe {
  id: number;
  name: string;
  district: string;
  rating: number;
  signature: string;
  address: string;
  hours: string;
  description: string;
}

export const cafes: Cafe[] = [
  {
    id: 1,
    name: '晨光烘焙咖啡馆',
    district: '静安区',
    rating: 4.8,
    signature: '手冲耶加雪菲',
    address: '静安区南京西路 188 号',
    hours: '08:00 - 21:00',
    description: '主打精品手冲与当日现烤面包，安静适合阅读。',
  },
  {
    id: 2,
    name: '街角豆子',
    district: '徐汇区',
    rating: 4.5,
    signature: '燕麦拿铁',
    address: '徐汇区武康路 77 号',
    hours: '09:00 - 22:00',
    description: '社区小店，燕麦拿铁奶香浓郁，常有熟客聚会。',
  },
  {
    id: 3,
    name: '云端咖啡实验室',
    district: '浦东新区',
    rating: 4.7,
    signature: '冷萃气泡美式',
    address: '浦东新区世纪大道 100 号',
    hours: '07:30 - 20:30',
    description: '写字楼里的咖啡实验室，冷萃气泡美式清爽提神。',
  },
  {
    id: 4,
    name: '梧桐树下',
    district: '徐汇区',
    rating: 4.9,
    signature: '桂花拿铁',
    address: '徐汇区衡山路 12 号',
    hours: '10:00 - 23:00',
    description: '法租界老洋房风格，桂花拿铁带有淡淡秋日香气。',
  },
  {
    id: 5,
    name: '旧城书房咖啡',
    district: '黄浦区',
    rating: 4.4,
    signature: '蜂蜜柚子茶咖',
    address: '黄浦区福州路 256 号',
    hours: '08:30 - 21:30',
    description: '书墙环绕的咖啡馆，蜂蜜柚子茶咖酸甜平衡。',
  },
  {
    id: 6,
    name: '北岸艺术咖啡',
    district: '静安区',
    rating: 4.6,
    signature: '海盐焦糖玛奇朵',
    address: '静安区大宁路 66 号',
    hours: '09:00 - 22:00',
    description: '定期举办小型画展，海盐焦糖玛奇朵甜而不腻。',
  },
];
