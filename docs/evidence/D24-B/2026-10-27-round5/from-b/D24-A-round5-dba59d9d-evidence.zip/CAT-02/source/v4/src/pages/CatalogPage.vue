<script setup lang="ts">
import { computed, ref } from 'vue';
import CafeCard from '../components/CafeCard.vue';
import CafeDetail from '../components/CafeDetail.vue';
import { cafes } from '../data/cafes';
import type { Cafe } from '../data/cafes';

const search = ref('');
const district = ref('全部城区');
const selectedId = ref<number | null>(null);

const districts = computed<string[]>(() => {
  const set = new Set<string>();
  cafes.forEach((c) => set.add(c.district));
  return ['全部城区', ...Array.from(set)];
});

const filtered = computed<Cafe[]>(() => {
  const q = search.value.trim();
  return cafes.filter((c) => {
    const byDistrict = district.value === '全部城区' || c.district === district.value;
    const byName = q === '' || c.name.includes(q);
    return byDistrict && byName;
  });
});

const selected = computed<Cafe | null>(() =>
  cafes.find((c) => c.id === selectedId.value) ?? null,
);

function selectCafe(id: number): void {
  selectedId.value = id;
}
</script>

<template>
  <main class="catalog">
    <h1 class="catalog__title" data-testid="catalog-page">城市咖啡馆目录</h1>
    <div class="catalog__controls">
      <label class="catalog__field">
        <span>搜索名称</span>
        <input v-model="search" data-testid="search-input" type="text" placeholder="输入咖啡馆名称" />
      </label>
      <label class="catalog__field">
        <span>城区筛选</span>
        <select v-model="district" data-testid="district-select">
          <option v-for="d in districts" :key="d" :value="d">{{ d }}</option>
        </select>
      </label>
    </div>
    <p class="catalog__count" data-testid="result-count">共 {{ filtered.length }} 家咖啡馆</p>
    <div class="catalog__list">
      <CafeCard
        v-for="cafe in filtered"
        :key="cafe.id"
        :cafe="cafe"
        @select="selectCafe"
      />
    </div>
    <p v-if="filtered.length === 0" class="catalog__empty">没有符合条件的咖啡馆</p>
    <CafeDetail v-if="selected" :cafe="selected" />
    <div v-else data-testid="cafe-detail"></div>
  </main>
</template>

<style scoped>
.catalog {
  max-width: 720px;
  margin: 0 auto;
  padding: 24px 16px;
  font-family: system-ui, sans-serif;
}
.catalog__title {
  margin: 0 0 16px;
  font-size: 22px;
}
.catalog__controls {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  margin-bottom: 12px;
}
.catalog__field {
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 13px;
  color: #7a6a58;
}
.catalog__field input,
.catalog__field select {
  padding: 6px 8px;
  border: 1px solid #d8cbba;
  border-radius: 6px;
  font: inherit;
  color: #333;
}
.catalog__count {
  margin: 0 0 12px;
  font-size: 13px;
  color: #7a6a58;
}
.catalog__list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.catalog__empty {
  font-size: 13px;
  color: #998877;
}
</style>
