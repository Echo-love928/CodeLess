<script setup lang="ts">
import type { Cafe } from '../data/cafes';

defineProps<{ cafe: Cafe }>();
</script>

<template>
  <section class="cafe-detail" data-ai-component="cafe-detail">
    <h2 class="cafe-detail__name">{{ cafe.name }}</h2>
    <p class="cafe-detail__district">{{ cafe.district }}</p>
    <p class="cafe-detail__rating">评分 {{ cafe.rating.toFixed(1) }}</p>
    <p class="cafe-detail__signature">招牌饮品：{{ cafe.signature }}</p>
    <p class="cafe-detail__address">地址：{{ cafe.address }}</p>
    <p class="cafe-detail__hours">营业时间：{{ cafe.hours }}</p>
    <p class="cafe-detail__description">{{ cafe.description }}</p>
  </section>
</template>

<style scoped>
.cafe-detail {
  margin-top: 20px;
  padding: 16px 18px;
  border: 1px solid #e0d6c8;
  border-radius: 12px;
  background: #fff8ef;
}
.cafe-detail__name {
  margin: 0 0 8px;
  font-size: 18px;
}
.cafe-detail p {
  margin: 0 0 6px;
  font-size: 13px;
  color: #5a4c3c;
}
</style>
