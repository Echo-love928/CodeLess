<script setup lang="ts">
import type { Cafe } from '../data/cafes';

defineProps<{ cafe: Cafe }>();

const emit = defineEmits<{ (e: 'select', id: number): void }>();
</script>

<template>
  <button
    type="button"
    class="cafe-card"
    data-ai-component="cafe-card"
    @click="emit('select', cafe.id)"
  >
    <h3 class="cafe-card__name">{{ cafe.name }}</h3>
    <p class="cafe-card__meta">{{ cafe.district }} · 评分 {{ cafe.rating.toFixed(1) }}</p>
    <p class="cafe-card__signature">招牌饮品：{{ cafe.signature }}</p>
  </button>
</template>

<style scoped>
.cafe-card {
  display: block;
  width: 100%;
  text-align: left;
  padding: 14px 16px;
  border: 1px solid #e0d6c8;
  border-radius: 10px;
  background: #fffdf9;
  cursor: pointer;
  font: inherit;
}
.cafe-card:hover {
  border-color: #b07d4a;
}
.cafe-card__name {
  margin: 0 0 6px;
  font-size: 16px;
}
.cafe-card__meta {
  margin: 0 0 4px;
  color: #7a6a58;
  font-size: 13px;
}
.cafe-card__signature {
  margin: 0;
  font-size: 13px;
}
</style>
